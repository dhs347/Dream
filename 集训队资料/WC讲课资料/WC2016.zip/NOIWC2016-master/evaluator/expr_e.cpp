#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>
#include <assert.h>

FILE *fin, *fout, *fans, *fsco, *fmsg;
std::ifstream ifs_out;
inline void score(int s, const char *message)
{
	// fprintf(fsco, "%d\n", s);
	// if (fmsg != NULL) fprintf(fmsg, "%s\n", message);
	
	fprintf(fmsg, "%s\n", message);
	fprintf(fmsg, "%d\n", s);
	
	fclose(fmsg);
	
	fclose(fin);
	// fclose(fsco);
	fclose(fans);
	// if (fout != NULL) fclose(fout);
	ifs_out.close();
	// if (fmsg != NULL) fclose(fmsg);
	exit(0);
}
inline void init_SPJ(int argc,char **argv)
{
	fin = fopen(argv[1], "r");   // input file 
	fans = fopen(argv[3], "r");
	// fsco = fopen(argv[5], "w");  // score output file (cannot be NULL)
	// fmsg = fopen(argv[6], "w");  // message output file (can be NULL)
	
	fmsg = fopen("/tmp/_eval.score", "w");
	
	// fout = fopen(argv[2], "r");  // contestant output file 
	ifs_out.open(argv[2],std::ifstream::in);
	if (!fin) return exit(0);
	// if (fout == NULL) fileNotFound();
}

int main(int argc,char **argv)
{
	init_SPJ(argc,argv);
	std::string s,s1,msg;
	std::getline(ifs_out,s);
	if (s!="49ed236be8f7cf5a0f49758a1f919c20") {
		score(0,"Unauthorized output");
	}
	int checksum_out, checksum_ans;
	std::getline(ifs_out,s1);
	assert(sscanf(s1.c_str(), "%d", &checksum_out) == 1);
	assert(fscanf(fans, "%d", &checksum_ans) == 1);
	
	std::getline(ifs_out,msg);
	
	if (checksum_out == checksum_ans) {
		msg = std::string("Correct! Calls of F(): ") + msg;
		score(10,msg.c_str());
	} else if (checksum_out == -1) {
		msg = std::string("Wrong Answer! ") + msg;
		score(0,msg.c_str());
	} else {
		msg = std::string("Wrong Answer! Incorrect checksum!");
		score(0,msg.c_str());
	}
}