#include "testlib.h"
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <climits>
#include <set>
#include <cstdlib>
using namespace std;

const int MaxN = 300;
const int MaxM = 100;

inline int getint()
{
	char c;
	while (c = getchar(), '0' > c || c > '9');

	int res = c - '0';
	while (c = getchar(), '0' <= c && c <= '9')
		res = res * 10 + c - '0';
	return res;
}

// adjust
template <class T>
inline bool relax(T &a, const T &b)
{
	if (b > a)
	{
		a = b;
		return true;
	}
	return false;
}
template <class T>
inline bool tension(T &a, const T &b)
{
	if (b < a)
	{
		a = b;
		return true;
	}
	return false;
}

int n, m;
set<pair<int, int> > es;

int readSol(InStream &in)
{
	int res = in.readInt(0, 100, "answer");
	static int b[MaxM + 1];
	int cur = m;
	for (int i = 1; i <= m; i++)
		b[i] = 0;
	for (int i = 1; i <= n; i++)
	{
		int p = in.readInt(1, 100, "p[i]");
		if (!(1 <= p && p <= m))
			in.quitf(_wa, "p[i] must be in range [1, m]");
		if (!(es.count(make_pair(i, p))))
			in.quitf(_wa, "ball #%d can't be placed in basket #%d", i, p);
		if (b[p]++ == 1)
			cur--;
		if (!(b[p] <= 3))
			in.quitf(_wa, "too many balls in basket #%d", p);
	}
	if (!(cur == res))
		in.quitf(_wa, "the number of semi-empty begs doesn't match the output");
	return res;
}

int score = 0;

void print_score()
{
	fprintf(stderr, "%d\n", score);
}

int main(int argc, char **argv)
{
	freopen("/tmp/_eval.score", "w", stderr);
	registerTestlibCmd(argc, argv);

	atexit(print_score);

	int nT = inf.readInt(1, 5, "T");
	inf.readEoln();

	while (nT--)
	{
		n = inf.readInt(1, 300, "n");
		inf.readSpace();
		m = inf.readInt(1, 100, "m");
		inf.readSpace();
		int e = inf.readInt(1, 30000, "e");
		inf.readEoln();

		for (int i = 0; i < e; i++)
		{
			int v, u;
			v = inf.readInt(1, n, "v");
			inf.readSpace();
			u = inf.readInt(1, m, "u");
			inf.readEoln();

			es.insert(make_pair(v, u));
		}

		int pa = readSol(ouf);
		int ja = readSol(ans);
		if (pa != ja)
			expectedButFound(_wa, ja, pa, "answer");
	}

	score = 10;
	quitf(_ok, "correct");
}
