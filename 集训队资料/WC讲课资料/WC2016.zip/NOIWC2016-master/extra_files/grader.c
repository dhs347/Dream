#include "expr.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#include <time.h>

#define debug(...) // fprintf(stderr,__VA_ARGS__)

static double clock_start;

inline static void __exit()
{
	debug("time: %.0lf ms\n",(clock()-clock_start)*1000.0/CLOCKS_PER_SEC);
	exit(0);
}

inline static void print_token()
{
	printf("49ed236be8f7cf5a0f49758a1f919c20\n");
}

inline static void WA()
{
	print_token();
	printf("-1\n");
}



static const int mo = 104857601;
static const int _g = 3;
static const int _g_inv = 34952534;

static int wn[2][30];

inline static int qpow(int a, int b, int p)
{
	while (p) {
		if (p & 1) a = 1LL * a * b % mo;
		b = 1LL * b * b % mo;
		p >>= 1;
	}
	return a;
}

inline static int getinv(int x)
{
	return qpow(1, x, mo - 2);
}

inline static void FFT_init()
{
	int i;
	for (i = 1; i <= 20; i++) {
		wn[0][i] = qpow(1, _g, (mo - 1) >> i);
		wn[1][i] = qpow(1, _g_inv, (mo - 1) >> i);
	}
}

inline static int bitrev(int x, int lgN)
{
	int ret = 0;
	int i;
	for (i = 0; i < lgN; i++) {
		ret |= ((x >> i) & 1) << (lgN - 1 - i);
	}
	return ret;
}

inline static void FFT(int *a, int lgN, bool rev)
{
	int i, j, k;
	int N = 1 << lgN;
	for (i = 0; i < N; i++) {
		int t = bitrev(i, lgN);
		if (i < t) {
			int tmp = a[i];
			a[i] = a[t];
			a[t] = tmp;
		}
	}
	for (i = 0; i < lgN; i++) {
		int t = 1 << i;
		int ww = wn[rev][i + 1];
		for (j = 0; j + t < N; j += t + t) {
			int *A = a + j;
			int w = 1;
			for (k = 0; k < t; k++) {
				long long tmp = 1LL * A[k + t] * w;
				A[k + t] = (A[k] - tmp) % mo;
				A[k] = (A[k] + tmp) % mo;
				w = 1LL * w * ww % mo;
			}
		}
	}
	for (i = 0; i < N; i++) {
		a[i] = (a[i] + mo) % mo;
	}
	if (rev) {
		int tmp = getinv(N);
		for (i = 0; i < N; i++) {
			a[i] = 1LL * a[i] * tmp % mo;
		}
	}
}

static int data_arr[1 << 17];
static int data_arr_size;
static int data_arr_pos;

inline static void put_int(int x)
{
	data_arr[++data_arr_size] = x;
}

inline static int get_int()
{
	return data_arr[++data_arr_pos];
}





#define MAXN 20005
#define MAXM 20005
#define MAX_K 105

static int rand_seed;

inline static int getrand()
{
	return rand_seed = rand_seed * 16807LL % 2147483647LL;
}

inline static void init_rand_seed()
{
	rand_seed = 758913712;
}

static int F_counter;

static int test_id;
static int n;
static int m;
static int k;
static int F_counter_limit;

#define u32 unsigned int

static u32 mask1[MAX_K];
static u32 mask2[MAX_K];

static int data_cnt;
static u32 _data[10100000];

inline static Data new_data()
{
	_data[++data_cnt] = getrand();
	return (Data){data_cnt};
}

inline static void init_masks()
{
	int i,j;
	for (i=1;i<=k;i++) {
		for (j=0;j<32;j++) {
			if ((getrand()>>17)&1) {
				mask1[i]|=1<<j;
			} else {
				mask2[i]|=1<<j;
			}
		}
	}
}

inline static u32 _F(u32 a, u32 b, int op)
{
	assert(op > 0 && op <= k);
	return (mask1[op]&((mask1[op]&a)+(mask1[op]&b)))
			|(mask2[op]&((mask2[op]&a)^(mask2[op]&b)));
}

Data F(Data a, Data b, int op)
{
	if (op < 1 || op > k) {
		WA();
		printf("Invalid operation (op = %d)\n", op);
		__exit();
	}
	if (a.x < 1 || a.x > data_cnt || b.x < 1 || b.x > data_cnt) {
		WA();
		printf("Invalid data\n");
		__exit();
	}
	++F_counter;
	if (F_counter > F_counter_limit) {
		WA();
		printf("Too many calls of F()\n");
		__exit();
	}
	++data_cnt;
	_data[data_cnt] = _F(_data[a.x], _data[b.x], op);
	return (Data){data_cnt};
}

static Data a[MAXN];
static int ops[MAXN];

static int _id[MAXM];
static int _type[MAXM];
static int _pos[MAXM];
static int _new_op[MAXM];
static int _l[MAXM];
static int _r[MAXM];



int main()
{
	freopen("expr.in", "rb", stdin);
	freopen("expr.out", "w", stdout);
	
	assert(fread(data_arr, 4, 1 << 17, stdin) == 1 << 17);
	
	FFT_init();
	FFT(data_arr, 17, 1);
	
	test_id = get_int();
	n = get_int();
	m = get_int();
	k = get_int();
	F_counter_limit = get_int();
	
	assert(n > 1 && n <= 20000);
	assert(m > 0 && m <= 20000);
	assert(k > 0 && k <= 100);
	
	assert(F_counter_limit > 0);
	
	init_rand_seed();
	init_masks();
	
	int i;
	for (i=0;i<n;i++) {
		a[i] = new_data();
	}
	
	for (i=1;i<n;i++) {
		ops[i] = get_int();
	}
	
	for (i=1;i<=m;i++) {
		_id[i] = get_int();
		assert(_id[i] >= 0 && _id[i] < i);
		
		_type[i] = get_int();
		
		if (_type[i] == 1) {
			_pos[i] = get_int();
			assert(_pos[i] >= 0 &&  _pos[i] < n);
		} else if (_type[i] == 2) {
			_pos[i] = get_int();
			_new_op[i] = get_int();
			assert(_pos[i] > 0 && _pos[i] < n);
			assert(_new_op[i] > 0 && _new_op[i] <= k);
		} else {
			assert(_type[i] == 3);
			_l[i] = get_int();
			_r[i] = get_int();
			assert(0 <= _l[i] && _l[i] <= _r[i] && _r[i] < n);
		}
	}
	
	init(test_id, n, m, k, a, ops);
	
	int checksum = 0;
	
	for (i=1;i<=m;i++) {
		Data ret;
		if (_type[i] == 1) {
			Data x = new_data();
			ret = modify_data(_id[i], _pos[i], x);
		} else if (_type[i] == 2) {
			ret = modify_op(_id[i], _pos[i], _new_op[i]);
		} else {
			assert(_type[i] == 3);
			ret = reverse(_id[i], _l[i], _r[i]);
		}
		if (ret.x < 1 || ret.x > data_cnt) {
			WA();
			printf("Invalid data\n");
			__exit();
		}
		checksum = (checksum * 998244353LL + _data[ret.x]) % 1000000009;
	}
	
	if (checksum < 0) {
		checksum += 1000000009;
	}
	
	print_token();
	
	printf("%d\n", checksum);
	
	printf("%d\n", F_counter);
	
	__exit();
	
}