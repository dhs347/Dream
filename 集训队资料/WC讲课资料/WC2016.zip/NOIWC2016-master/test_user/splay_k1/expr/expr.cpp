#include "expr.h"
#include <algorithm>
#include <assert.h>

// k = 1 -- splay

#define MAXN 100005
#define MAXM 100005

struct node {
	node *s[2],*fa;
	int size;
	Data x,sum;
	bool rev;
	
	inline void add_rev_tag()
	{
		rev^=1;
		std::swap(s[0],s[1]);
	}
	
	inline void down()
	{
		if (rev) {
			rev=0;
			if (s[0]) s[0]->add_rev_tag();
			if (s[1]) s[1]->add_rev_tag();
		}
	}
	
	inline void update()
	{
		sum=x;
		size=1;
		if (s[0]) sum=F(s[0]->sum,sum,1),size+=s[0]->size;
		if (s[1]) sum=F(sum,s[1]->sum,1),size+=s[1]->size;
	}
};

inline int get_dir(node *x,node *&fa)
{
	return (fa=x->fa) ? fa->s[1]==x : -1;
}

inline void rotate(node *x)
{
	int t1,t2;
	node *fa,*gfa;
	t1=get_dir(x,fa);
	t2=get_dir(fa,gfa);
	if ((fa->s[t1]=x->s[t1^1])) fa->s[t1]->fa=fa;
	x->s[t1^1]=fa;
	fa->fa=x;x->fa=gfa;
	if (t2!=-1) gfa->s[t2]=x;
	fa->update();
}

inline void pushdown(node *x)
{
	if (x->fa) pushdown(x->fa);
	x->down();
}

inline node * splay(node *x)
{
	pushdown(x);
	while (1) {
		int t1,t2;
		node *fa,*gfa;
		t1=get_dir(x,fa);
		if (t1==-1) break;
		t2=get_dir(fa,gfa);
		if (t2==-1) {
			rotate(x);break;
		} else if (t1==t2) {
			rotate(fa);rotate(x);
		} else {
			rotate(x);rotate(x);
		}
	}
	x->update();
	return x;
}

inline node * find_kth(node *a,int k)
{
	while (1) {
		a->down();
		int cnt=a->s[0]?a->s[0]->size:0;
		if (k<=cnt) {
			a=a->s[0];
		} else if (k>cnt+1) {
			k-=cnt+1;
			a=a->s[1];
		} else {
			break;
		}
	}
	return a;
}

node _nodes[MAXN],*root;

int test_id,n,m,k;

inline node * build(const Data *a,int l,int r)
{
	if (l>r) return NULL;
	int mid=(l+r)>>1;
	node *ret=_nodes+mid;
	ret->s[0]=build(a,l,mid-1);
	ret->s[1]=build(a,mid+1,r);
	if (ret->s[0]) ret->s[0]->fa=ret;
	if (ret->s[1]) ret->s[1]->fa=ret;
	ret->x=a[mid];
	ret->rev=0;
	ret->update();
	return ret;
}

inline node * modify(node *root,int pos,Data x)
{
	node *t=find_kth(root,pos);
	splay(t)->x=x;
	t->update();
	return t;
}

inline node * reverse(node *root,int l,int r)
{
	node *t1=find_kth(root,l);
	node *L=splay(t1)->s[0];
	if (L) L->fa=NULL;
	t1->s[0]=NULL;
	if (L) t1->update();
	node *t2=find_kth(t1,r-l+1);
	node *R=splay(t2)->s[1];
	if (R) R->fa=NULL;
	t2->s[1]=NULL;
	if (R) t2->update();
	t2->add_rev_tag();
	t2=splay(find_kth(t2,1));
	if (L) t2->s[0]=L,L->fa=t2,t2->update();
	t2=splay(find_kth(t2,r));
	if (R) t2->s[1]=R,R->fa=t2,t2->update();
	return t2;
}

// precedences: 1 ~ k, larger is higher
void init(int test_id, int n, int m, int k, const Data *a, const int *ops)
{
	::test_id=test_id;
	::n=n;
	::m=m;
	::k=k;
	assert(k==1);
	int i;
	for (i=1;i<n;i++) {
		assert(ops[i]==1);
	}
	root=build(a,0,n-1);
}

int q_id;

Data modify_data(int id, int pos, Data x)
{
	++q_id;
	assert(id==q_id-1);
	return (root=modify(root,pos+1,x))->sum;
}

// modify the operator between pos and pos - 1
Data modify_op(int id, int pos, int new_op)
{
	++q_id;
	assert(id==q_id-1);
	return root->sum;
}

Data reverse(int id, int l, int r)
{
	++q_id;
	assert(id==q_id-1);
	return (root=reverse(root,l+1,r+1))->sum;
}
