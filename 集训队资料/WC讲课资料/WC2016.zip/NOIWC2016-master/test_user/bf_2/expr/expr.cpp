#include "expr.h"
#include <algorithm>
#include <string.h>
#include <stdlib.h>

// brute force -- stack

#define MAXN 100005
#define MAXM 100005

int test_id,n,m,k;
int q_id;

Data *a[MAXM];
int *ops[MAXM];

inline Data query()
{
	static Data stack[MAXN];
	static int stack_op[MAXN];
	int top=1;
	stack[1]=a[q_id][0];
	int i;
	for (i=1;i<n;i++) {
		int t=ops[q_id][i];
		while (top>1 && t<=stack_op[top]) {
			stack[top-1]=F(stack[top-1],stack[top],stack_op[top]);
			--top;
		}
		stack[++top]=a[q_id][i];
		stack_op[top]=t;
	}
	while (top>1) {
		stack[top-1]=F(stack[top-1],stack[top],stack_op[top]);
		--top;
	}
	return stack[1];
}

// precedences: 1 ~ k, larger is higher
void init(int test_id, int n, int m, int k, const Data *a, const int *ops)
{
	::test_id=test_id;
	::n=n;
	::m=m;
	::k=k;
	::a[0]=new Data[n];
	::ops[0]=new int[n];
	int i;
	for (i=0;i<n;i++) {
		::a[0][i]=a[i];
	}
	for (i=1;i<n;i++) {
		::ops[0][i]=ops[i];
	}
}

inline void copy_data(int dst_id,int src_id)
{
	a[dst_id]=new Data[n];
	ops[dst_id]=new int[n];
	memcpy(a[dst_id],a[src_id],n*sizeof(Data));
	memcpy(ops[dst_id]+1,ops[src_id]+1,(n-1)*sizeof(int));
}

Data modify_data(int id, int pos, Data x)
{
	copy_data(++q_id,id);
	a[q_id][pos]=x;
	return query();
}

// modify the operator between pos and pos - 1
Data modify_op(int id, int pos, int new_op)
{
	copy_data(++q_id,id);
	ops[q_id][pos]=new_op;
	return query();
}

Data reverse(int id, int l, int r)
{
	copy_data(++q_id,id);
	std::reverse(a[q_id]+l,a[q_id]+r+1);
	std::reverse(ops[q_id]+l+1,ops[q_id]+r+1);
	return query();
}
