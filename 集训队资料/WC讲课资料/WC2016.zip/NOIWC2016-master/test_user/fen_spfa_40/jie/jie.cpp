#include <algorithm>
#include <iostream>
#include <assert.h>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <bitset>
#include <ctime>
#include <cmath>
#include <queue>
#include <map>
#include <set>
#define fi first
#define se second
#define PA pair<int,int>
#define VI vector<int>
#define VP vector<PA >
#define mk(x,y) make_pair(x,y)
#define int64 long long
#define db double
#define N 200010
#define M 10000000
#define For(i,x,y) for (i=x;i<=y;i++)
using namespace std;
const int inf=(int)2e9;
int i,j,k,n,m,t,u,X,Y,Z,tt,len,T;
int64 K,an;
int f[N],g[N],he[M],ne[M],c[M],b[M],Len[N],a[M],h[M];
bool ff[M];
char p[N];
priority_queue<PA > dui;
inline void Clear() {
	tt=0;
	For(i,0,u-1) he[i]=ff[i]=0;
	u=n;
}
inline void work() {
	int i;
	For(i,n,u-1) a[i]=inf;
	int l=0,r=0;
	For(i,0,n-1) if (a[i]<inf) h[++r]=i,ff[i]=1; 
	for (;l!=r;) {
		l=(l+1)%(M-10);
		int A=h[l],v;
		ff[A]=0;
		for (v=he[A];v;v=ne[v]) {
			int B=c[v];
			if (a[B]>a[A]+b[v]) {
				a[B]=a[A]+b[v];
				if (!ff[B]) {
					r=(r+1)%(M-10);
					ff[B]=1;
					h[r]=B;
				}
			}
		}
	}
	Clear();
}
inline void add(int x,int y,int z) {
	c[++tt]=y,b[tt]=z,ne[tt]=he[x],he[x]=tt;
}
inline int C(int x,int y) {
	return x+y*Y;
}
inline void lu(int x_1,int y_1,int x_2,int yl,int yr,int v) {
	int A=yl/Z,B=yr/Z;
	int vv=v+(yr-yl)*Y;
	if (A==B) {
		if (!yl) add(C(x_1,y_1)%n,u+n+C(x_2,yr),vv);
		else add(C(x_1,y_1)%n,u+C(x_2,yl),v);
	} else {
		add(C(x_1,y_1)%n,u+C(x_2,yl),v);
		add(C(x_1,y_1)%n,u+n+C(x_2,yr),vv);
	}
}
inline void gao(int &x,int &y,int i) {
	x=i%Y; y=(i-x)/Y;
}
inline void into(int x,int y,int z) {
	int i,j,k;
	len=n/y+(n%y>0);
	X=x; Y=y; Z=z;
	{
		int Last=n%y;
		if (!Last) Last=y;
		For(i,0,Last-1) Len[i]=len;
		For(i,Last,y-1) Len[i]=len-1;
	}
	For(i,0,n-1) {
		int xx,yy,x_,y_;
		gao(xx,yy,i);
		
		int wei=(i+x)%n;
		if (wei+y*(z-1)>=n) {
			int ge=(n-wei-1)/y+1;
			gao(x_,y_,wei);
			lu(xx,yy,x_,y_,(y_+ge-1),x);
			if (y_+ge-1!=Len[x_]-1)
			k=1;
			assert(y_+ge-1==Len[x_]-1);
			
			wei=(wei+ge*y)%n;
			gao(x_,y_,wei);
			lu(xx,yy,x_,y_,y_+(z-ge)-1,x+ge*y);
			assert(y_==0);
		} else {
			gao(x_,y_,wei);
			lu(xx,yy,x_,y_,y_+z-1,x);
		}
	}
	{
		For(i,0,y-1) {
			for (j=0;j<Len[i];)
			for (k=1;k<=z&&j<Len[i];j++,k++) {
				if (k>1) {
					add(u+C(i,j-1),u+C(i,j),y);
					add(u+n+C(i,j),u+n+C(i,j-1),-y);
				}
				{
					add(u+C(i,j),C(i,j)%n,0);
					add(u+n+C(i,j),C(i,j)%n,0);
				}
			}
		}
		u+=n*2;
	}
	work(); 
}
inline void print() {
	//int ma=0;
	an=0; 
	For(i,0,n-1) if (a[i]<1e9&&a[i]<=K) {
		an+=(K-a[i])/n+1;
		//ma=max(ma,a[i]);
	}
	printf("%lld\n",an);
	//cerr<<ma<<endl;
}
int main() {
	freopen("jie.in","r",stdin);
	freopen("jie.out","w",stdout);
	scanf("%d",&T);
	for (;T;T--) {
		scanf("%d%lld",&n,&K);
		scanf("%s",p+1);
		for (j=0,i=2;i<=n;i++) {
			for (;j&&p[j+1]!=p[i];j=f[j]);
			if (p[j+1]==p[i]) j++;
			f[i]=j;
		}
		t=0;
		for (i=f[n];i;i=f[i]) g[++t]=n-i;
		//g[++t]=n;
		{
			For(i,0,n-1) a[i]=inf;
			a[0]=n; u=n;
		}
		for (i=1;i<=t;i=j) {
			if (i==t) {
				into(g[i],1,1);
				break;
			}
			for (j=i+2;j<=t&&g[j]-g[j-1]==g[i+1]-g[i];j++);
			into(g[i],g[i+1]-g[i],j-i);
		}
		print();
		//cerr<<clock()<<endl;
	}
	//cerr<<clock()<<endl;
	return 0;
}
