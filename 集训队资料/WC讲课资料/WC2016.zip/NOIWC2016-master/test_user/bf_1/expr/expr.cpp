#include "expr.h"
#include <algorithm>
#include <assert.h>

// brute force -- stack

#define MAXN 100005

int test_id,n,m,k;
int q_id;

Data a[MAXN];
int ops[MAXN];

inline Data query()
{
	static Data stack[MAXN];
	static int stack_op[MAXN];
	int top=1;
	stack[1]=a[0];
	int i;
	for (i=1;i<n;i++) {
		int t=ops[i];
		while (top>1 && t<=stack_op[top]) {
			stack[top-1]=F(stack[top-1],stack[top],stack_op[top]);
			--top;
		}
		stack[++top]=a[i];
		stack_op[top]=t;
	}
	while (top>1) {
		stack[top-1]=F(stack[top-1],stack[top],stack_op[top]);
		--top;
	}
	return stack[1];
}

// precedences: 1 ~ k, larger is higher
void init(int test_id, int n, int m, int k, const Data *a, const int *ops)
{
	::test_id=test_id;
	::n=n;
	::m=m;
	::k=k;
	int i;
	for (i=0;i<n;i++) {
		::a[i]=a[i];
	}
	for (i=1;i<n;i++) {
		::ops[i]=ops[i];
	}
}

Data modify_data(int id, int pos, Data x)
{
	++q_id;
	assert(id==q_id-1);
	a[pos]=x;
	return query();
}

// modify the operator between pos and pos - 1
Data modify_op(int id, int pos, int new_op)
{
	++q_id;
	assert(id==q_id-1);
	ops[pos]=new_op;
	return query();
}

Data reverse(int id, int l, int r)
{
	++q_id;
	assert(id==q_id-1);
	std::reverse(a+l,a+r+1);
	std::reverse(ops+l+1,ops+r+1);
	return query();
}
