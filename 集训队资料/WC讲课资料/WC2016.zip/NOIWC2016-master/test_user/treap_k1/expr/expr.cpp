#include "expr.h"
#include <algorithm>
#include <assert.h>
#include <stdio.h>

// k = 1 -- fully persistent treap

#define MAXN 100005
#define MAXM 100005
#define MAX_NODE (MAXM*300)

#define u32 unsigned int

inline u32 getrand()
{
	static u32 ret=245353253;
	return ret=ret*16807ull%2147483647ull;
}

struct node {
	node *l,*r;
	u32 pri;
	int size;
	Data x,sum;
	bool rev;
	
	inline void update()
	{
		sum=x;
		size=1;
		if (l) sum=F(l->sum,sum,1),size+=l->size;
		if (r) sum=F(sum,r->sum,1),size+=r->size;
	}
};

node _pool[MAX_NODE],*_pool_tot=_pool;

inline node * new_node()
{
	return ++_pool_tot;
}

inline node * copy_node(node *a)
{
	node *ret=new_node();
	*ret=*a;
	return ret;
}

inline node * add_rev_tag(node *a)
{
	node *ret=copy_node(a);
	ret->rev^=1;
	std::swap(ret->l,ret->r);
	return ret;
}

inline node * down(node *a)
{
	if (a->rev) {
		node *ret=copy_node(a);
		ret->rev=0;
		if (ret->l) ret->l=add_rev_tag(ret->l);
		if (ret->r) ret->r=add_rev_tag(ret->r);
		return ret;
	} else {
		return a;
	}
}

inline node * join(node *a,node *b)
{
	if (!a) return b;
	if (!b) return a;
	node *ret;
	if (a->pri<b->pri) {
		a=down(a);
		ret=copy_node(a);
		ret->r=join(a->r,b);
	} else {
		b=down(b);
		ret=copy_node(b);
		ret->l=join(a,b->l);
	}
	ret->update();
	return ret;
}

inline void split(node *a,int n,node *&l,node *&r)
{
	if (!n) return l=NULL,r=a,void();
	if (n==a->size) return l=a,r=NULL,void();
	a=down(a);
	int cnt=a->l?a->l->size:0;
	node *tmp=copy_node(a);
	if (n<=cnt) {
		split(a->l,n,l,r);
		// a->l=r;r=a;
		tmp->l=r;
		tmp->update();
		r=tmp;
	} else {
		split(a->r,n-cnt-1,l,r);
		// a->r=l;l=a;
		tmp->r=l;
		tmp->update();
		l=tmp;
	}
}

node *root[MAXM];
int test_id,n,m,k;
int q_id;

inline node * build(const Data *a,const u32 *pri,int l,int r)
{
	if (l>r) return NULL;
	node *ret=new_node();
	int i;
	int best=l;
	for (i=l+1;i<=r;i++) {
		if (pri[i]<pri[best]) best=i;
	}
	ret->x=a[best];
	ret->rev=0;
	ret->l=build(a,pri,l,best-1);
	ret->r=build(a,pri,best+1,r);
	ret->update();
	ret->pri=pri[best];
	return ret;
}

// precedences: 1 ~ k, larger is higher
void init(int test_id, int n, int m, int k, const Data *a, const int *ops)
{
	::test_id=test_id;
	::n=n;
	::m=m;
	::k=k;
	assert(k==1);
	int i;
	for (i=1;i<n;i++) {
		assert(ops[i]==1);
	}
	static u32 pri[MAXN];
	for (i=0;i<n;i++) {
		pri[i]=getrand();
	}
	root[0]=build(a,pri,0,n-1);
}

inline node * modify(node *a,int pos,Data x)
{
	a=down(a);
	int cnt=a->l?a->l->size:0;
	node *ret=copy_node(a);
	if (pos<=cnt) {
		ret->l=modify(ret->l,pos,x);
	} else if (pos==cnt+1) {
		ret->x=x;
	} else {
		ret->r=modify(ret->r,pos-cnt-1,x);
	}
	ret->update();
	return ret;
}

inline node * reverse(node *a,int l,int r)
{
	node *t1,*t2,*t3;
	split(a,l-1,t1,t2);
	split(t2,r-l+1,t2,t3);
	return join(join(t1,add_rev_tag(t2)),t3);
}

Data modify_data(int id, int pos, Data x)
{
	return (root[++q_id]=modify(root[id],pos+1,x))->sum;
}

// modify the operator between pos and pos - 1
Data modify_op(int id, int pos, int new_op)
{
	assert(new_op==1);
	return (root[++q_id]=root[id])->sum;
}

Data reverse(int id, int l, int r)
{
	return (root[++q_id]=reverse(root[id],l+1,r+1))->sum;
}
