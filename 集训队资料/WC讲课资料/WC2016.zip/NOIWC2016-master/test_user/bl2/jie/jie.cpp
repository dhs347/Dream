#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <bitset>
#include <ctime>
#include <cmath>
#include <map>
#include <set>
#define fi first
#define se second
#define PA pair<int,int>
#define VI vector<int>
#define VP vector<PA >
#define mk(x,y) make_pair(x,y)
#define int64 long long
#define db double
#define N 200010
#define M 1000000
#define P 32
#define int32 unsigned int
#define For(i,x,y) for (i=x;i<=y;i++)
using namespace std;
int i,j,k,n,m,S;
int64 K;
int f[N];
char p[N];
struct ww {
	int i,len,xx,yy;
	int32 a[N],b[40],c[40];
	void gao(int &x,int &y,int n) {
		x=n/P; y=n%P;
	}
	void clear() {
		For(i,0,len) a[i]=0;
	}
	void gai(int n) {
		gao(xx,yy,n);
		a[xx]|=1ll<<yy;
	}
	int wen(int n) {
		gao(xx,yy,n);
		return a[xx]>>yy&1;
	}
	void into(int n) {
		gao(xx,yy,n);
		len=xx;
		gai(0);
		For(i,1,P) {
			b[i]=(1ll<<i)-1;
			c[i]=b[i]<<(P-i);
		}
	}
	void jia(int m) {
		if (m<=P) {
			For(i,m,K) if (wen(i-m)) gai(i);
		} else {
			gao(xx,yy,m);
			For(i,0,len-xx) {
				S++;
				int A=P-yy;
				a[i+xx]|=(a[i]&b[A])<<yy;
				if (i+xx<len&&yy) a[i+xx+1]|=(a[i]&c[yy])>>A;
			}
		}
	}
	int cal() {
		int an=0;
		For(i,0,K) an+=wen(i);
		return an;
	}
} a;
inline void pre() {
	scanf("%d%lld",&n,&K);
	scanf("%s",p+1);
	for (i=2,j=0;i<=n;i++) {
		for (;j&&p[j+1]!=p[i];j=f[j]);
		if (p[j+1]==p[i]) j++;
		f[i]=j;
	}
}
inline void work() {
	a.clear();
	int64 kk=0;
	if (K>1000000) {
		kk=K-1000000;
		K=1000000;
	}
	K-=n;
	a.into(K);
	for (i=f[n];i;i=f[i]) a.jia(n-i);
	a.jia(n);
	printf("%lld\n",a.cal()+kk);
}
int main() {
	freopen("jie.in","r",stdin);
	freopen("jie.out","w",stdout);
	int T;
	//int tim=clock();
	scanf("%d",&T);
	S=0;
	for (;T;T--) {
		pre();
		//if (T==5||T==2) continue;
		work();
	}
	//cerr<<"#ci : "<<S<<"   ";
	//cerr<<te<<" ";
	//cerr<<clock()-tim<<endl;
	return 0;
}
