#include <algorithm>
#include <iostream>
#include <assert.h>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <bitset>
#include <ctime>
#include <cmath>
#include <queue>
#include <map>
#include <set>
#define fi first
#define se second
#define PA pair<int,int>
#define VI vector<int>
#define VP vector<PA >
#define mk(x,y) make_pair(x,y)
#define int64 long long
#define db double
#define N 200010
#define M 10000000
#define For(i,x,y) for (i=x;i<=y;i++)
using namespace std;
struct ww {
	int l,r;
} tr[M];
const int inf=(int)2e9;
int i,j,k,n,m,t,u,X,Y,Z,tt,len,T;
int64 K,an;
int f[N],g[N],he[M],ne[M],c[M],b[M],Len[N],a[M],ro[N];
bool ff[M];
char p[N];
priority_queue<PA > dui;
inline void add(int x,int y,int z) {
	assert(z>=0);
	c[++tt]=y,b[tt]=z,ne[tt]=he[x],he[x]=tt;
}
inline void gao(int &x,int &y,int i) {
	x=i%Y; y=(i-x)/Y;
}
void build(int &q,int x,int y,int i) {
	if (x==y) {
		q=x*Y+i;
		return;
	}
	q=u++;
	int mid=(x+y)/2;
	build(tr[q].l,x,mid,i);
	build(tr[q].r,mid+1,y,i);
	add(q,tr[q].l,0);
	add(q,tr[q].r,(mid-x+1)*Y);
}
void jia(int q,int x,int y,int l,int r,int i,int k) {
	if (l<=x&&y<=r) {
		add(i,q,k+(x-l)*Y);
		return;
	}
	int mid=(x+y)/2;
	if (l<=mid) jia(tr[q].l,x,mid,l,r,i,k);
	if (mid<r) jia(tr[q].r,mid+1,y,l,r,i,k);
}
inline void into(int x,int y,int z) {
	int i,j;
	len=n/y+(n%y>0);
	X=x; Y=y; Z=z;
	{
		int Last=n%y;
		if (!Last) Last=y;
		For(i,0,Last-1) Len[i]=len;
		For(i,Last,y-1) Len[i]=len-1;
	}
	For(i,0,y-1) {
		ro[i]=0;
		build(ro[i],0,Len[i]-1,i);
	}
	For(i,0,n-1) {
		int xx,yy,x_,y_;
		int wei=(i+x)%n;
		gao(xx,yy,i);
		gao(x_,y_,wei);
		
		if (wei+y*(z-1)>=n) {
			int ge=(n-wei-1)/y+1;
			jia(ro[x_],0,Len[x_]-1,y_,Len[x_]-1,i,x);
			
			wei=(wei+ge*y)%n;
			gao(x_,y_,wei);
			jia(ro[x_],0,Len[x_]-1,0,(z-ge)-1,i,x+ge*y);
		} else jia(ro[x_],0,Len[x_]-1,y_,y_+z-1,i,x);
	}
}
inline void work() {
	int i;
	//cerr<<t<<" "<<u<<" "<<tt<<endl;
	For(i,0,u-1) a[i]=inf;
	a[0]=n; dui.push(mk(-n,0));
	for (;!dui.empty();) {
		PA A=dui.top();
		dui.pop();
		int v,x=A.se,y=-A.fi;
		if (ff[x]) continue;
		ff[x]=1;
		for (v=he[x];v;v=ne[v]) {
			int z=c[v];
			if (a[z]>y+b[v]) {
				a[z]=y+b[v];
				dui.push(mk(-a[z],z));
			}
		}
	}
}
inline void print() {
	//int ma=0;
	//For(i,0,n-1) printf("%d\n",a[i]);
	an=0;
	For(i,0,n-1) if (a[i]<1e9&&a[i]<=K) {
		an+=(K-a[i])/n+1;
		//ma=max(ma,a[i]);
	}
	printf("%lld\n",an);
	//cerr<<ma<<endl;
}
inline void Clear() {
	tt=0;
	For(i,0,u-1) he[i]=ff[i]=tr[i].l=tr[i].r=0;
}
int main() {
	freopen("jie.in","r",stdin);
	freopen("jie.out","w",stdout);
	scanf("%d",&T);
	for (;T;T--) {
		//int tim=clock();
		scanf("%d%lld",&n,&K);
		scanf("%s",p+1);
		for (j=0,i=2;i<=n;i++) {
			for (;j&&p[j+1]!=p[i];j=f[j]);
			if (p[j+1]==p[i]) j++;
			f[i]=j;
		}
		t=0;
		for (i=f[n];i;i=f[i]) g[++t]=n-i;
		u=n;
		for (i=1;i<=t;i=j) {
			if (i==t) {
				into(g[i],1,1);
				break;
			}
			for (j=i+2;j<=t&&g[j]-g[j-1]==g[i+1]-g[i];j++);
			into(g[i],g[i+1]-g[i],j-i);
		}
		work();
		print();
		Clear();
		//cerr<<"time : "<<clock()-tim<<endl;
	}
	//cerr<<te<<endl;
	return 0;
}
