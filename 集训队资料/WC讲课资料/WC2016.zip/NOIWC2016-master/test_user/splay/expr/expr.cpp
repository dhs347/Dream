#include "expr.h"
#include <algorithm>
#include <assert.h>
#include <stdio.h>

// std -- splay

#define MAXN 100005
#define MAX_NODE (MAXN*24)

struct node {
	node *s[2],*fa,*ch;
	int size;
	int level;
	Data x,sum;
	bool rev;
	
	inline int get_self_size()
	{
		return ch ? ch->size : 1;
	}
	
	inline void add_rev_tag()
	{
		rev^=1;
		std::swap(s[0],s[1]);
	}
	
	inline void down()
	{
		if (rev) {
			rev=0;
			if (s[0]) s[0]->add_rev_tag();
			if (s[1]) s[1]->add_rev_tag();
			if (ch) ch->add_rev_tag();
		}
	}
	
	inline void update()
	{
		if (ch) {
			size=ch->size;
			sum=ch->sum;
		} else {
			size=1;
			sum=x;
		}
		if (s[0]) sum=F(s[0]->sum,sum,level),size+=s[0]->size;
		if (s[1]) sum=F(sum,s[1]->sum,level),size+=s[1]->size;
	}
};

node _nodes[MAX_NODE],*_pool[MAX_NODE],**_pool_top=_pool;

inline void init_node_pool()
{
	int i;
	for (i=0;i<MAX_NODE;i++) {
		*(_pool_top++)=_nodes+i;
	}
}

inline node * new_node()
{
	return *(--_pool_top);
}

inline void del_node(node *x)
{
	*(_pool_top++)=x;
}

inline int get_dir(node *x,node *&fa)
{
	return (fa=x->fa) ? fa->s[1]==x : -1;
}

inline void rotate(node *x)
{
	int t1,t2;
	node *fa,*gfa;
	t1=get_dir(x,fa);
	t2=get_dir(fa,gfa);
	if ((fa->s[t1]=x->s[t1^1])) fa->s[t1]->fa=fa;
	x->s[t1^1]=fa;
	fa->fa=x;
	x->fa=gfa;
	if (t2!=-1) gfa->s[t2]=x;
	fa->update();
}

inline void pushdown(node *x)
{
	if (x->fa) pushdown(x->fa);
	x->down();
}

inline node * splay(node *x)
{
	pushdown(x);
	while (1) {
		int t1,t2;
		node *fa,*gfa;
		t1=get_dir(x,fa);
		if (t1==-1) break;
		t2=get_dir(fa,gfa);
		if (t2==-1) {
			rotate(x);break;
		} else {
			rotate(t1==t2 ? fa : x);
			rotate(x);
		}
	}
	x->update();
	return x;
}

inline node * find_kth(node *a,int k)
{
	while (1) {
		a->down();
		int cnt=a->s[0]?a->s[0]->size:0;
		int cnt2=cnt+a->get_self_size();
		if (k<=cnt) {
			a=a->s[0];
		} else if (k>cnt2) {
			a=a->s[1];
			k-=cnt2;
		} else {
			break;
		}
	}
	return a;
}

inline node * dec_level(node *a,int level)
{
	assert(a->level>=level);
	if (a->level==level) {
		return a;
	}
	node *ret=new_node();
	ret->s[0]=ret->s[1]=ret->fa=NULL;
	ret->ch=a;
	ret->level=level;
	ret->rev=0;
	ret->update();
	return ret;
}

inline node * join(node *a,node *b)
{
	if (!a) return b;
	if (!b) return a;
	node *_a=a,*_b=b;
	while (1) {
		a->down();
		b->down();
		if (a->s[1] && b->s[0]) {
			a=a->s[1];
			b=b->s[0];
		} else {
			break;
		}
	}
	if (!a->s[1]) {
		splay(a)->s[1]=_b;
		_b->fa=a;
		a->update();
		return a;
	} else {
		splay(b)->s[0]=_a;
		_a->fa=b;
		b->update();
		return b;
	}
}

inline node * inc_level(node *a)
{
	a->down();
	node *ret=a->ch;
	del_node(a);
	return ret;
}

inline int split(node *a,int n,node *&l,node *&r)
{
	if (!n) return l=NULL,r=a,a->level;
	if (n==a->size) return l=a,r=NULL,a->level;
	a=splay(find_kth(a,n));
	node *L=a->s[0],*R=a->s[1];
	if (L) L->fa=NULL,n-=L->size;
	if (R) R->fa=NULL;
	a->s[0]=a->s[1]=NULL;
	a->update();
	int ret=a->level;
	if (!n) {
		a->s[1]=R;
		if (R) R->fa=a;
		a->update();
		l=L;r=a;
	} else if (n==a->size) {
		a->s[0]=L;
		if (L) L->fa=a;
		a->update();
		l=a;r=R;
	} else {
		int _level=a->level;
		ret=split(inc_level(a),n,l,r);
		assert(l);
		assert(r);
		l=join(L,dec_level(l,_level));
		r=join(dec_level(r,_level),R);
	}
	return ret;
}

inline void split_r_ch(node *a,node *&l,node *&r)
{
	while (1) {
		a->down();
		if (a->s[1]) {
			a=a->s[1];
		} else {
			break;
		}
	}
	l=splay(a)->s[0];
	if (l) l->fa=NULL;
	r=inc_level(a);
}

inline void split_l_ch(node *a,node *&l,node *&r)
{
	while (1) {
		a->down();
		if (a->s[0]) {
			a=a->s[0];
		} else {
			break;
		}
	}
	r=splay(a)->s[1];
	if (r) r->fa=NULL;
	l=inc_level(a);
}

inline node * join(node *a,node *b,int level)
{
	if (!a) return b;
	if (!b) return a;
	if (a->level>level) {
		a=dec_level(a,level);
	}
	if (b->level>level) {
		b=dec_level(b,level);
	}
	if (a->level==level && b->level==level) {
		return join(a,b);
	} else if (a->level<b->level) {
		assert(a->level<level);
		int _level=a->level;
		node *t1,*t2;
		split_r_ch(a,t1,t2);
		t2=join(t2,b,level);
		return join(t1,dec_level(t2,_level));
	} else {
		assert(b->level<level);
		int _level=b->level;
		node *t1,*t2;
		split_l_ch(b,t1,t2);
		t1=join(a,t1,level);
		return join(dec_level(t1,_level),t2);
	}
}

node *root;

int test_id,n,m,k;
int q_id;

inline node * new_node(Data x)
{
	node *ret=new_node();
	ret->s[0]=ret->s[1]=ret->ch=ret->fa=NULL;
	ret->level=k+1;
	ret->x=x;
	ret->rev=0;
	ret->update();
	return ret;
}

// precedences: 1 ~ k, larger is higher
void init(int test_id, int n, int m, int k, const Data *a, const int *ops)
{
	init_node_pool();
	::test_id=test_id;
	::n=n;
	::m=m;
	::k=k;
	root=new_node(a[0]);
	int i;
	for (i=1;i<n;i++) {
		root=join(root,new_node(a[i]),ops[i]);
	}
}

inline node * modify_data(node *a,int pos,Data x)
{
	a->down();
	int cnt=a->s[0]?a->s[0]->size:0;
	int cnt2=cnt+a->get_self_size();
	if (pos<=cnt) {
		return modify_data(a->s[0],pos,x);
	} else if (pos>cnt2)  {
		return modify_data(a->s[1],pos-cnt2,x);
	} else if (a->ch) {
		a->ch=modify_data(a->ch,pos-cnt,x);
		return splay(a);
	} else {
		a->x=a->sum=x;
		return a;
	}
}

inline node * modify_op(node *a,int pos,int new_op)
{
	node *t1,*t2;
	split(a,pos,t1,t2);
	return join(t1,t2,new_op);
}

inline node * reverse(node *a,int l,int r)
{
	node *t1,*t2,*t3;
	int op_l,op_r;
	op_l=split(a,l-1,t1,t2);
	op_r=split(t2,r-l+1,t2,t3);
	t2->add_rev_tag();
	return join(t1,join(t2,t3,op_r),op_l);
}

Data modify_data(int id, int pos, Data x)
{
	++q_id;
	assert(id==q_id-1);
	return (root=modify_data(root,pos+1,x))->sum;
}

// modify the operator between pos and pos - 1
Data modify_op(int id, int pos, int new_op)
{
	++q_id;
	assert(id==q_id-1);
	return (root=modify_op(root,pos,new_op))->sum;
}

Data reverse(int id, int l, int r)
{
	++q_id;
	assert(id==q_id-1);
	return (root=reverse(root,l+1,r+1))->sum;
}
