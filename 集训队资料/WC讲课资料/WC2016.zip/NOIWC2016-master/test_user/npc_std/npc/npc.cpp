#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;

const int MaxNBall = 300;
const int MaxNBasket = 100;

const int MaxN = MaxNBall + MaxNBasket * 3;
const int MaxM = MaxNBall * MaxNBasket * 3 + MaxNBasket;

inline int getint()
{
	char c;
	while (c = getchar(), '0' > c || c > '9');

	int res = c - '0';
	while (c = getchar(), '0' <= c && c <= '9')
		res = res * 10 + c - '0';
	return res;
}

struct halfEdge
{
	int u;
	halfEdge *next;
};
halfEdge adj_pool[MaxM * 2], *adj_tail;

int n, m;
halfEdge *adj[MaxN + 1];

int mate[MaxN + 1];
int q_n;
int q[MaxN];
int col[MaxN + 1], next[MaxN + 1], bel[MaxN + 1];

inline void adjInit()
{
	adj_tail = adj_pool;
	for (int v = 1; v <= n; v++)
		adj[v] = NULL;
}

inline void addEdge(int v, int u)
{
	adj_tail->u = u, adj_tail->next = adj[v], adj[v] = adj_tail++;
}

inline int get_lca(int v, int u)
{
	v = bel[v], u = bel[u];
	static bool book[MaxN + 1];
	fill(book + 1, book + n + 1, false);
	while (true)
	{
		if (v)
		{
			if (book[v])
				return v;
			book[v] = true;
			v = mate[v] ? bel[next[mate[v]]] : 0;
		}
		swap(v, u);
	}
}
int cnt = 0;
inline void go_up(int v, int u, int mv)
{
	while (bel[v] != mv)
	{
		next[v] = u;
		if (col[mate[v]] == 1)
			col[mate[v]] = 0, q[q_n++] = mate[v];
		if (v == bel[v])
			bel[v] = mv;
		if (mate[v] == bel[mate[v]])
			bel[mate[v]] = mv;
		u = mate[v];
		v = next[mate[v]];
	}
}
inline void after_go_up()
{
	for (int v = 1; v <= n; v++)
		bel[v] = bel[bel[v]];
}
bool match(int sv)
{
	q_n = 0;
	for (int v = 1; v <= n; v++)
		col[v] = -1, bel[v] = v;
	col[sv] = 0, q[q_n++] = sv;
	for (int i = 0; i < q_n; i++)
	{
		int v = q[i];
		for (halfEdge *e = adj[v]; e; e = e->next)
		{
			if (col[e->u] == -1)
			{
				next[e->u] = v, col[e->u] = 1;
				int nv = mate[e->u];
				if (!nv)
				{
					int u = e->u;
					while (u)
					{
						int nu = mate[next[u]];
						mate[u] = next[u], mate[next[u]] = u;
						u = nu;
					}
					return true;
				}
				col[nv] = 0, q[q_n++] = nv;
			}
			else if (bel[v] != bel[e->u] && col[e->u] == 0)
			{
				int lca = get_lca(v, e->u);
				go_up(v, e->u, lca);
				go_up(e->u, v, lca);
				after_go_up();
			}
		}
	}
	return false;
}

int nBall, nBasket;

inline int ball(int i)
{
	return i;
}
inline int basket(int i, int k)
{
	return nBall + (i - 1) * 3 + k;
}
inline int basket_num(int v)
{
	return (v - nBall + 2) / 3;
}

void handle()
{
	for (int v = 1; v <= n; v++)
		col[v] = -1, bel[v] = v, mate[v] = 0;
	for (int v = 1; v <= nBall; v++)
		if (!match(ball(v)))
		{
			printf("-1\n");
			return;
		}

	int res = 0;
	for (int u = 1; u <= nBasket; u++)
		for (int k = 1; k <= 3; k++)
			if (!mate[basket(u, k)] && match(basket(u, k)))
				res++;

	printf("%d\n", res);
	for (int v = 1; v <= nBall; v++)
		printf("%d ", basket_num(mate[v]));
	printf("\n");
}

int main()
{
	freopen("npc.in", "r", stdin);
	freopen("npc.out", "w", stdout);
	int nT = getint();

	while (nT--)
	{
		nBall = getint(), nBasket = getint();
		
		int nRel = getint();

		n = nBall + nBasket * 3;

		adjInit();
		for (int i = 0; i < nRel; i++)
		{
			int v = getint(), u = getint();
			for (int k = 1; k <= 3; k++)
				addEdge(ball(v), basket(u, k)), addEdge(basket(u, k), ball(v));
		}
		for (int u = 1; u <= nBasket; u++)
			addEdge(basket(u, 2), basket(u, 3)), addEdge(basket(u, 3), basket(u, 2));

		handle();
	}

	return 0;
}
