#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <bitset>
#include <ctime>
#include <cmath>
#include <map>
#include <set>
#define fi first
#define se second
#define PA pair<int,int>
#define VI vector<int>
#define VP vector<PA >
#define mk(x,y) make_pair(x,y)
#define int64 long long
#define db double
#define N 100010
#define For(i,x,y) for (i=x;i<=y;i++)
using namespace std;
int i,j,k,n,m,Mi,t;
int64 K,an;
int f[N],g[N*100],h[N],a[N],ff[N],zhi[N];
char p[N];
set<int> Set;
inline void pre() {
	scanf("%d%lld",&n,&K);
	scanf("%s",p+1);
	for (j=0,i=2;i<=n;i++) {
		for (;j&&p[j+1]!=p[i];j=f[j]);
		if (p[j+1]==p[i]) j++;
		f[i]=j;
	}
	Mi=n;
	if (f[n]) Mi=n-f[n];
	t=0; Set.clear();
	for (i=f[n];i;i=f[i]) {
		int A=n-i;
		int B=A;
		A%=Mi;
		if (!Set.count(A)) {
			Set.insert(A);
			g[++t]=B;
		}
	}
	if (!Set.count(n%Mi)) g[++t]=n;
}
inline void work() {
	int i;
	memset(a,120,sizeof(a));
	a[0]=n; h[1]=0;
	int l=0,r=1%Mi;
	for (;l!=r;) {
		l=(l+1)%Mi;
		int A=h[l];
		ff[A]=0;
		For(i,1,t) {
			int B=(A+g[i])%Mi;
			if (a[B]>a[A]+g[i]) {
				a[B]=a[A]+g[i];
				if (!ff[B]) {
					r=(r+1)%Mi;
					ff[B]=1;
					h[r]=B;
				}
			}
		}
	}
}
inline void print() {
	an=0;
	For(i,0,Mi) if (a[i]<1e9&&a[i]<=K) an+=(K-a[i])/Mi+1;
	printf("%lld\n",an);
}
int main() {
	freopen("jie.in","r",stdin);
	freopen("jie.out","w",stdout);
	int T;
	//int tim=clock();
	scanf("%d",&T);
	for (;T;T--) {
		pre();
		//if (T==5) continue;
		work();
		print();
	}
	//cerr<<te<<" ";
	//cerr<<clock()-tim<<endl;
	return 0;
}
