#include "expr.h"
#include <vector>
#include <cstdio>
using namespace std;
int n,m,k,top;
vector <Data> a[20010];
vector <int> ops[20010];
// precedences: 1 ~ k, larger is higher
void init(int test_id, int nn, int mm, int kk, const Data *aa, const int *opss)
{
	n=nn;
	m=mm;
	k=kk;
	for(int i=0;i<n;++i)
		a[0].push_back(aa[i]);
	ops[0].push_back(0);
	for(int i=1;i<n;++i)
		ops[0].push_back(opss[i]);
}

Data getval(int now,int l,int r,int w)
{
	if(l==r)
		return a[now][l];
	for(int i=l+1;i<=r;++i)
		if(ops[now][i]==w)
			return F(getval(now,l,i-1,w+1),getval(now,i,r,w),ops[now][i]);
	return getval(now,l,r,w+1);
}

Data modify_data(int id, int pos, Data x)
{
	++top;
	a[top]=a[id];
	ops[top]=ops[id];
	a[top][pos]=x;
	return getval(top,0,n-1,1);
}

// modify the operator between pos and pos - 1
Data modify_op(int id, int pos, int new_op)
{
	++top;
	a[top]=a[id];
	ops[top]=ops[id];
	ops[top][pos]=new_op;
	return getval(top,0,n-1,1);
}

Data reverse(int id, int l, int r)
{
	++top;
	a[top]=a[id];
	ops[top]=ops[id];
	Data tmp;
	int tmpp;
	for(int i=0;l+i<r-i;++i)
	{
		tmp=a[top][l+i];
		a[top][l+i]=a[top][r-i];
		a[top][r-i]=tmp;
		tmpp=ops[top][l+i+1];
		ops[top][l+i+1]=ops[top][r-i];
		ops[top][r-i]=tmpp;
	}
	return getval(top,0,n-1,1);
}

