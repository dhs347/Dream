#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <bitset>
#include <ctime>
#include <cmath>
#include <map>
#include <set>
#define fi first
#define se second
#define PA pair<int,int>
#define VI vector<int>
#define VP vector<PA >
#define mk(x,y) make_pair(x,y)
#define int64 long long
#define db double
#define N 1000010
#define M 10000000
#define For(i,x,y) for (i=x;i<=y;i++)
using namespace std;
struct ww {
	int l,r;
} tr[N];
const int inf=(int)1e9;
int i,j,k,n,m,t,u,X,tt;
int64 K,an;
int f[N],g[N],he[N],ne[M],c[M],b[M],ro[N],len[N],a[N],h[N],ff[N];
char p[N];
inline void add(int x,int y,int z) {
	c[++tt]=y,b[tt]=z,ne[tt]=he[x],he[x]=tt;
}
void build(int &q,int x,int y,int _) {
	if (x==y) {
		q=x*X+_+1;
		return;
	}
	q=++u;
	int mid=(x+y)/2;
	build(tr[q].l,x,mid,_);
	build(tr[q].r,mid+1,y,_);
	add(q,tr[q].l,0);
	add(q,tr[q].r,(mid-x+1)*X);
}
void jia(int q,int x,int y,int l,int r,int _,int k) {
	if (l<=x&&y<=r) {
		add(_,q,k+x*X);
		return;
	}
	int mid=(x+y)/2;
	if (l<=mid) jia(tr[q].l,x,mid,l,r,_,k);
	if (mid<r) jia(tr[q].r,mid+1,y,l,r,_,k);
}
inline void into(int x,int y,int z) {
	int i,j;
	X=y;
	For(i,0,y-1) {
		len[i]=(n-1-i)/y;
		ro[i]=0;
		build(ro[i],0,len[i],i);
	}
	For(i,0,n-1) {
		int L=(i+x)%n;
		int A=L%y,B=L/y,r=B+z-1;
		if (r<=len[A]) jia(ro[A],0,len[A],B,r,i+1,x-B*X);
		else {
			jia(ro[A],0,len[A],B,len[A],i+1,x-B*X);
			int Len=(len[A]-B+1)*X,shu=r-len[A]-1;
			A=(L+Len)%n%y;
			jia(ro[A],0,len[A],0,shu,i+1,Len+x);
		}
	}
}
inline void work() {
	int i;
	For(i,1,u) a[i]=inf;
	int l=0,r=1%u;
	a[1]=n; h[r]=1;
	for (;l!=r;) {
		l=(l+1)%u;
		int A=h[l],v;
		ff[A]=0;
		for (v=he[A];v;v=ne[v]) {
			int B=c[v];
			if (a[B]>a[A]+b[v]) {
				a[B]=a[A]+b[v];
				if (!ff[B]) {
					r=(r+1)%u;
					ff[B]=1;
					h[r]=B;
				}
			}
		}
	}
}
inline void print() {
	an=0;
	//For(i,1,n) printf("%d\n",a[i]);
	For(i,1,n) if (a[i]<1e9&&a[i]<=K) an+=(K-a[i])/n+1;
	printf("%lld\n",an);
}
void clear() {
	memset(tr,0,sizeof(tr));
	memset(he,0,sizeof(he));
	tt=0;
}
int main() {
	freopen("jie.in","r",stdin);
	freopen("jie.out","w",stdout);
	int T;
	scanf("%d",&T);
	for (;T;T--) {
		//int ti=clock();
		clear();
		scanf("%d%lld",&n,&K);
		scanf("%s",p+1);
		for (j=0,i=2;i<=n;i++) {
			for (;j&&p[j+1]!=p[i];j=f[j]);
			if (p[j+1]==p[i]) j++;
			f[i]=j;
		}
		t=0;
		for (i=f[n];i;i=f[i]) g[++t]=n-i;
		//g[++t]=n;
		u=n;
		for (i=1;i<=t;i=j) {
			if (i==t) {
				into(g[i],1,1);
				break;
			}
			for (j=i+2;j<=t&&g[j]-g[j-1]==g[i+1]-g[i];j++);
			into(g[i],g[i+1]-g[i],j-i);
		}
		work();
		print();
		//cerr<<T<<" "<<clock()-ti<<" "<<tt<<endl;
	}
	return 0;
}
