#include "expr.h"
#include <algorithm>
#include <assert.h>
#include <stdio.h>

// std -- fully persistent treap

#define MAXN 100005
#define MAXM 100005
#define MAX_NODE (MAXM*300)

#define u32 unsigned int

inline u32 getrand()
{
	static u32 ret=12765218;
	return ret=ret*16807ull%2147483647ull;
}

inline bool getrand(u32 a,u32 b)
{
	// rnd < a/b
	return (1ull*getrand()*b)>>31<a;
}

struct node {
	node *l,*r,*ch;
	int size;
	int level;
	Data x,sum;  // !ch || x
	bool rev;
	
	inline int get_self_size()
	{
		return ch ? ch->size : 1;
	}
	
	inline void update()
	{
		if (ch) {
			size=ch->size;
			sum=ch->sum;
		} else {
			size=1;
			sum=x;
		}
		if (l) sum=F(l->sum,sum,level),size+=l->size;
		if (r) sum=F(sum,r->sum,level),size+=r->size;
	}
};

node _pool[MAX_NODE],*_pool_tot=_pool;

inline node * new_node()
{
	return ++_pool_tot;
}

inline node * copy_node(node *a)
{
	node *ret=new_node();
	*ret=*a;
	return ret;
}

inline node * add_rev_tag(node *a)
{
	node *ret=copy_node(a);
	ret->rev^=1;
	std::swap(ret->l,ret->r);
	return ret;
}

inline node * down(node *a)
{
	if (a->rev) {
		node *ret=copy_node(a);
		ret->rev=0;
		if (ret->l) ret->l=add_rev_tag(ret->l);
		if (ret->r) ret->r=add_rev_tag(ret->r);
		if (ret->ch) ret->ch=add_rev_tag(ret->ch);
		return ret;
	} else {
		return a;
	}
}

inline node * join(node *a,node *b);
inline node * dec_level(node *a,int level);

inline int split(node *a,int n,node *&l,node *&r)
{
	if (!n) return l=NULL,r=a,a->level;
	if (n==a->size) return l=a,r=NULL,a->level;
	a=down(a);
	int cnt=a->l?a->l->size:0;
	int cnt2=cnt+a->get_self_size();
	int ret;
	if (n<=cnt) {
		ret=split(a->l,n,l,r);
		// a->l=r;r=a;
		node *tmp=copy_node(a);
		tmp->l=r;
		tmp->update();
		r=tmp;
	} else if (n>=cnt2) {
		ret=split(a->r,n-cnt2,l,r);
		// a->r=l;l=a;
		node *tmp=copy_node(a);
		tmp->r=l;
		tmp->update();
		l=tmp;
	} else {
		ret=split(a->ch,n-cnt,l,r);
		l=join(a->l,dec_level(l,a->level));
		r=join(dec_level(r,a->level),a->r);
	}
	return ret;
}

inline node * dec_level(node *a,int level)
{
	assert(a->level>=level);
	if (a->level==level) {
		return a;
	}
	node *ret=new_node();
	ret->l=ret->r=NULL;
	ret->ch=a;
	ret->level=level;
	ret->rev=0;
	ret->update();
	return ret;
}

inline node * join(node *a,node *b)
{
	if (!a) return b;
	if (!b) return a;
	node *ret;
	if (getrand(a->size,a->size+b->size)) {
		a=down(a);
		ret=copy_node(a);
		ret->r=join(a->r,b);
	} else {
		b=down(b);
		ret=copy_node(b);
		ret->l=join(a,b->l);
	}
	ret->update();
	return ret;
}

inline void split_r_ch(node *a,node *&l,node *&r)
{
	a=down(a);
	if (a->r) {
		split_r_ch(a->r,l,r);
		node *tmp=copy_node(a);
		tmp->r=l;
		tmp->update();
		l=tmp;
	} else {
		r=a->ch;
		l=a->l;
	}
}

inline void split_l_ch(node *a,node *&l,node *&r)
{
	a=down(a);
	if (a->l) {
		split_l_ch(a->l,l,r);
		node *tmp=copy_node(a);
		tmp->l=r;
		tmp->update();
		r=tmp;
	} else {
		l=a->ch;
		r=a->r;
	}
}

inline node * join(node *a,node *b,int level)
{
	if (!a) return b;
	if (!b) return a;
	if (a->level>level) {
		a=dec_level(a,level);
	}
	if (b->level>level) {
		b=dec_level(b,level);
	}
	if (a->level==level && b->level==level) {
		return join(a,b);
	} else if (a->level<b->level) {
		assert(a->level<level);
		node *t1,*t2;
		split_r_ch(a,t1,t2);
		t2=join(t2,b,level);
		return join(t1,dec_level(t2,a->level));
	} else {
		assert(b->level<level);
		node *t1,*t2;
		split_l_ch(b,t1,t2);
		t1=join(a,t1,level);
		return join(dec_level(t1,b->level),t2);
	}
}

node *root[MAXM];

int test_id,n,m,k;
int q_id;

inline node * new_node(Data x)
{
	node *ret=new_node();
	ret->l=ret->r=ret->ch=NULL;
	ret->level=k+1;
	ret->x=x;
	ret->rev=0;
	ret->update();
	return ret;
}

// precedences: 1 ~ k, larger is higher
void init(int test_id, int n, int m, int k, const Data *a, const int *ops)
{
	::test_id=test_id;
	::n=n;
	::m=m;
	::k=k;
	root[0]=new_node(a[0]);
	int i;
	for (i=1;i<n;i++) {
		root[0]=join(root[0],new_node(a[i]),ops[i]);
	}
}

inline node * modify_data(node *a,int pos,Data x)
{
	a=down(a);
	int cnt=a->l?a->l->size:0;
	int cnt2=cnt+a->get_self_size();
	node *ret=copy_node(a);
	if (pos<=cnt) {
		ret->l=modify_data(a->l,pos,x);
	} else if (pos>cnt2) {
		ret->r=modify_data(a->r,pos-cnt2,x);
	} else if (a->ch) {
		ret->ch=modify_data(a->ch,pos-cnt,x);
	} else {
		ret->x=x;
	}
	ret->update();
	return ret;
}

inline node * modify_op(node *a,int pos,int new_op)
{
	node *t1,*t2;
	split(a,pos,t1,t2);
	return join(t1,t2,new_op);
}

inline node * reverse(node *a,int l,int r)
{
	node *t1,*t2,*t3;
	int op_l,op_r;
	op_l=split(a,l-1,t1,t2);
	op_r=split(t2,r-l+1,t2,t3);
	return join(t1,join(add_rev_tag(t2),t3,op_r),op_l);
}

Data modify_data(int id, int pos, Data x)
{
	return (root[++q_id]=modify_data(root[id],pos+1,x))->sum;
}

// modify the operator between pos and pos - 1
Data modify_op(int id, int pos, int new_op)
{
	return (root[++q_id]=modify_op(root[id],pos,new_op))->sum;
}

Data reverse(int id, int l, int r)
{
	return (root[++q_id]=reverse(root[id],l+1,r+1))->sum;
}
