#include "expr.h"
#include <algorithm>
#include <assert.h>
#include <stdio.h>
#include <vector>

#define MAXN 20005
#define MAXM 20005
#define MAXK 105
#define MAX_NODE MAXN

int test_id,n,m,k;
int q_id;


// input: a[0] op[1] a[1] ...
// returns: stack_size; stack[1] _op[2] stack[2] ...
inline int build_stack(const Data *a,const int *ops,int n,Data *stack,int *stack_op)
{
	assert(n>0);
	stack[1]=a[0];
	int size=1;
	int i;
	for (i=1;i<n;i++) {
		int t=ops[i];
		while (size>1 && t<=stack_op[size]) {
			stack[size-1]=F(stack[size-1],stack[size],stack_op[size]);
			--size;
		}
		stack[++size]=a[i];
		stack_op[size]=t;
	}
	return size;
}

inline Data evaluate(const Data *a,const int *ops,int n)
{
	static Data stack[MAXK+5];
	static int stack_op[MAXK+5];
	int size=build_stack(a,ops,n,stack,stack_op);
	while (size>1) {
		stack[size-1]=F(stack[size-1],stack[size],stack_op[size]);
		--size;
	}
	return stack[1];
}

struct expr {
	int len;
	std::vector<Data> a;
	std::vector<int> ops;  // a[i] ops[i] a[i+1]
	
	inline Data evaluate()
	{
		return ::evaluate(&a.front(),&ops.front()-1,len);
	}
	
	inline void reverse()
	{
		std::reverse(a.begin(),a.end());
		if (len>1) {
			std::reverse(ops.begin(),ops.end());
		}
	}
};

inline expr reverse(expr a)
{
	a.reverse();
	return a;
}

inline expr simplify(const expr &a)
{
	if (a.len<=3) {
		// a; a+b; a+b+c; a+b*c;
		return a;
	}
	int min_op=k+1;
	int pos1=-1,pos2=-1;
	int i;
	for (i=0;i<a.len-1;i++) {
		int t=a.ops[i];
		if (t<min_op) {
			min_op=t;
			pos1=pos2=i;
		} else if (t==min_op) {
			pos2=i;
		}
	}
	expr ret;
	static Data _a[MAXN];
	static int _ops[MAXN];
	int cnt1=pos1+1;
	std::copy(a.a.begin(),a.a.begin()+cnt1,_a);
	std::copy(a.ops.begin(),a.ops.begin()+cnt1,_ops+1);
	std::reverse(_a,_a+cnt1);
	std::reverse(_ops+1,_ops+cnt1);
	static Data stack[MAXK+5];
	static int stack_op[MAXK+5];
	int size=build_stack(_a,_ops,cnt1,stack,stack_op);
	ret.a.assign(stack+1,stack+size+1);
	ret.ops.assign(stack_op+2,stack_op+size+1);
	std::reverse(ret.a.begin(),ret.a.end());
	std::reverse(ret.ops.begin(),ret.ops.end());
	ret.ops.push_back(min_op);
	if (pos1<pos2) {
		ret.a.push_back(evaluate(&a.a.front()+cnt1,&a.ops.front()+cnt1-1,pos2-pos1));
		ret.ops.push_back(min_op);
	}
	size=build_stack(&a.a.front()+pos2+1,&a.ops.front()+pos2,a.len-pos2-1,stack,stack_op);
	ret.a.insert(ret.a.end(),stack+1,stack+size+1);
	ret.ops.insert(ret.ops.end(),stack_op+2,stack_op+size+1);
	ret.len=ret.a.size();
	return ret;
}

inline expr join(const expr &a,int op1,Data x,int op2,const expr &b)
{
	expr tmp=a;
	tmp.a.push_back(x);
	tmp.ops.push_back(op1);
	tmp.ops.push_back(op2);
	tmp.a.insert(tmp.a.end(),b.a.begin(),b.a.end());
	tmp.ops.insert(tmp.ops.end(),b.ops.begin(),b.ops.end());
	tmp.len=tmp.a.size();
	return simplify(tmp);
}

inline expr join(const expr &a,int op1,Data x)
{
	expr tmp=a;
	tmp.a.push_back(x);
	tmp.ops.push_back(op1);
	tmp.len=tmp.a.size();
	return simplify(tmp);
}

inline expr join(Data x,int op2,const expr &b)
{
	return reverse(join(reverse(b),op2,x));
}

inline expr get_expr(Data x)
{
	expr ret;
	ret.len=1;
	ret.a.push_back(x);
	return ret;
}



#define u32 unsigned int

inline u32 getrand()
{
	static u32 ret=12578612;
	return ret=ret*16807ull%2147483647ull;
}

struct node {
	node *l,*r;
	u32 pri;
	int size;
	int op_l,op_r;
	Data x;
	expr e;
	bool rev;
	
	inline void add_rev_tag()
	{
		rev^=1;
		std::swap(op_l,op_r);
		std::swap(l,r);
		e.reverse();
	}
	
	inline void down()
	{
		if (rev) {
			rev=0;
			if (l) l->add_rev_tag();
			if (r) r->add_rev_tag();
		}
	}
	
	inline void update()
	{
		if (l && r) {
			e=join(l->e,op_l,x,op_r,r->e);
		} else if (l) {
			e=join(l->e,op_l,x);
		} else if (r) {
			e=join(x,op_r,r->e);
		} else {
			e=get_expr(x);
		}
		size=1;
		if (l) size+=l->size;
		if (r) size+=r->size;
	}
	
	inline Data get_sum()
	{
		return e.evaluate();
	}
};

node _pool[MAX_NODE],*_pool_tot=_pool;

inline node * new_node()
{
	return ++_pool_tot;
}

inline node * join(node *a,int op,node *b)
{
	if (!a) return b;
	if (!b) return a;
	if (a->pri<b->pri) {
		a->down();
		if (!a->r) a->op_r=op;
		a->r=join(a->r,op,b);
		a->update();
		return a;
	} else {
		b->down();
		if (!b->l) b->op_l=op;
		b->l=join(a,op,b->l);
		b->update();
		return b;
	}
}

inline int split(node *a,int n,node *&l,node *&r)
{
	if (!n) return l=NULL,r=a,0;
	if (n==a->size) return l=a,r=NULL,0;
	a->down();
	int cnt=a->l?a->l->size:0;
	int ret;
	if (n<=cnt) {
		ret=split(a->l,n,l,r);
		if (!ret) ret=a->op_l;
		a->l=r;r=a;
	} else {
		ret=split(a->r,n-cnt-1,l,r);
		if (!ret) ret=a->op_r;
		a->r=l;l=a;
	}
	a->update();
	return ret;
}

node *root[MAXM];

inline node * build(const Data *a,const int *ops,const u32 *pri,int l,int r)
{
	if (l>r) return NULL;
	node *ret=new_node();
	int i;
	int best=l;
	for (i=l+1;i<=r;i++) {
		if (pri[i]<pri[best]) best=i;
	}
	ret->x=a[best];
	ret->rev=0;
	ret->l=build(a,ops,pri,l,best-1);
	ret->r=build(a,ops,pri,best+1,r);
	if (ret->l) ret->op_l=ops[best];
	if (ret->r) ret->op_r=ops[best+1];
	ret->pri=pri[best];
	ret->update();
	return ret;
}

// precedences: 1 ~ k, larger is higher
void init(int test_id, int n, int m, int k, const Data *a, const int *ops)
{
	::test_id=test_id;
	::n=n;
	::m=m;
	::k=k;
	static u32 pri[MAXN];
	int i;
	for (i=0;i<n;i++) {
		pri[i]=getrand();
	}
	root[0]=build(a,ops,pri,0,n-1);
	// printf("init ok root e size = %d %d %d\n",root[0]->e.len,(int)root[0]->e.a.size(),
	// 	(int)root[0]->e.ops.size());fflush(stdout);
}

inline node * modify_data(node *a,int pos,Data x)
{
	a->down();
	int cnt=a->l?a->l->size:0;
	if (pos<=cnt) {
		modify_data(a->l,pos,x);
	} else if (pos==cnt+1) {
		a->x=x;
	} else {
		modify_data(a->r,pos-cnt-1,x);
	}
	a->update();
	return a;
}

inline node * modify_op(node *a,int pos,int new_op)
{
	node *t1,*t2;
	split(a,pos,t1,t2);
	return join(t1,new_op,t2);
}

inline node * reverse(node *a,int l,int r)
{
	node *t1,*t2,*t3;
	int op1,op2;
	op1=split(a,l-1,t1,t2);
	op2=split(t2,r-l+1,t2,t3);
	t2->add_rev_tag();
	return join(join(t1,op1,t2),op2,t3);
}

Data modify_data(int id, int pos, Data x)
{
	assert(id==q_id);
	return (root[++q_id]=modify_data(root[id],pos+1,x))->get_sum();
}

// modify the operator between pos and pos - 1
Data modify_op(int id, int pos, int new_op)
{
	assert(id==q_id);
	return (root[++q_id]=modify_op(root[id],pos,new_op))->get_sum();
}

Data reverse(int id, int l, int r)
{
	assert(id==q_id);
	return (root[++q_id]=reverse(root[id],l+1,r+1))->get_sum();
}
