#include <vector>
#include <algorithm>
#include <assert.h>
#include <stdio.h>

// input: a[0] op[1] a[1] ...
// returns: stack_size; stack[1] _op[2] stack[2] ...
inline int build_stack(const Data *a,const int *ops,int n,Data *stack,int *stack_op)
{
	assert(n>0);
	stack[1]=a[0];
	int size=1;
	int i;
	for (i=1;i<n;i++) {
		int t=ops[i];
		while (size>1 && t<=stack_op[size]) {
			stack[size-1]=F(stack[size-1],stack[size],stack_op[size]);
			--size;
		}
		stack[++size]=a[i];
		stack_op[size]=t;
	}
	return size;
}

inline Data evaluate(const Data *a,const int *ops,int n)
{
	static Data stack[MAXK+5];
	static int stack_op[MAXK+5];
	int size=build_stack(a,ops,n,stack,stack_op);
	while (size>1) {
		stack[size-1]=F(stack[size-1],stack[size],stack_op[size]);
		--size;
	}
	return stack[1];
}

struct expr {
	int len;
	std::vector<Data> a;
	std::vector<int> ops;  // a[i] ops[i] a[i+1]
	
	inline Data evaluate()
	{
		return ::evaluate(&a.front(),&ops.front()-1,len);
	}
	
	inline void reverse()
	{
		std::reverse(a.begin(),a.end());
		if (len>1) {
			std::reverse(ops.begin(),ops.end());
		}
	}
};

inline expr reverse(expr a)
{
	a.reverse();
	return a;
}

inline expr simplify(const expr &a)
{
	if (a.len<=3) {
		// a; a+b; a+b+c; a+b*c;
		return a;
	}
	int min_op=k+1;
	int pos1=-1,pos2=-1;
	int i;
	for (i=0;i<a.len-1;i++) {
		int t=a.ops[i];
		if (t<min_op) {
			min_op=t;
			pos1=pos2=i;
		} else if (t==min_op) {
			pos2=i;
		}
	}
	expr ret;
	static Data _a[MAXN];
	static int _ops[MAXN];
	int cnt1=pos1+1;
	std::copy(a.a.begin(),a.a.begin()+cnt1,_a);
	std::copy(a.ops.begin(),a.ops.begin()+cnt1,_ops+1);
	std::reverse(_a,_a+cnt1);
	std::reverse(_ops+1,_ops+cnt1);
	static Data stack[MAXK+5];
	static int stack_op[MAXK+5];
	int size=build_stack(_a,_ops,cnt1,stack,stack_op);
	ret.a.assign(stack+1,stack+size+1);
	ret.ops.assign(stack_op+2,stack_op+size+1);
	std::reverse(ret.a.begin(),ret.a.end());
	std::reverse(ret.ops.begin(),ret.ops.end());
	ret.ops.push_back(min_op);
	if (pos1<pos2) {
		ret.a.push_back(evaluate(&a.a.front()+cnt1,&a.ops.front()+cnt1-1,pos2-pos1));
		ret.ops.push_back(min_op);
	}
	size=build_stack(&a.a.front()+pos2+1,&a.ops.front()+pos2,a.len-pos2-1,stack,stack_op);
	ret.a.insert(ret.a.end(),stack+1,stack+size+1);
	ret.ops.insert(ret.ops.end(),stack_op+2,stack_op+size+1);
	ret.len=ret.a.size();
	return ret;
}

inline expr join(const expr &a,int op1,Data x,int op2,const expr &b)
{
	expr tmp=a;
	tmp.a.push_back(x);
	tmp.ops.push_back(op1);
	tmp.ops.push_back(op2);
	tmp.a.insert(tmp.a.end(),b.a.begin(),b.a.end());
	tmp.ops.insert(tmp.ops.end(),b.ops.begin(),b.ops.end());
	tmp.len=tmp.a.size();
	return simplify(tmp);
}

inline expr join(const expr &a,int op1,Data x)
{
	expr tmp=a;
	tmp.a.push_back(x);
	tmp.ops.push_back(op1);
	tmp.len=tmp.a.size();
	return simplify(tmp);
}

inline expr join(Data x,int op2,const expr &b)
{
	return reverse(join(reverse(b),op2,x));
}

inline expr get_expr(Data x)
{
	expr ret;
	ret.len=1;
	ret.a.push_back(x);
	return ret;
}

