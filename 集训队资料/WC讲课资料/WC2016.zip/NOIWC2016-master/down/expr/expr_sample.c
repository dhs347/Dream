#include "expr.h"

// precedences: 1 ~ k, larger is higher
void init(int test_id, int n, int m, int k, const Data *a, const int *ops)
{
	
}

Data modify_data(int id, int pos, Data x)
{
	
}

// modify the operator between pos and pos - 1
Data modify_op(int id, int pos, int new_op)
{
	
}

Data reverse(int id, int l, int r)
{
	
}
