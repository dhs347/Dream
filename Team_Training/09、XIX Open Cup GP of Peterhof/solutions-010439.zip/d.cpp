
#include "bits/stdc++.h"

using namespace std;

typedef long long int64;



typedef tuple<int,int,int> Node;

const int O_XOR = 6;
const int O_OR = 14;
const int O_AND = 8;
const int O_1 = 12;
const int O_2 = 10;
const int O_NOT1 = 3;
const int O_NOT2 = 5;
const int O_id0 = 0;
const int O_id1 = 15;
const int O_EQ = 9;
const int O_GT = 4;
const int O_LS = 2;
const int O_xANDnoty = 4;
const int O_notxANDnoty = 1;
const int O_notxORy = 11;
const int O_notxANDy = 2;


struct Circuit {
  // a function is encoded as a binary number from 0 to 15
  int N;
  vector<Node> nodes;
  int gate0, gate1;
  Circuit (int _N): N(_N) {
    assert(N > 0);
    nodes.resize(N);
    nodes.push_back(make_tuple(0,0,O_id0));
    nodes.push_back(make_tuple(0,0,O_id1));
    gate0 = (int)nodes.size() - 2;
    gate1 = (int)nodes.size() - 1;  
  }
  
  int compute_binary(int x, int y, int f) {
    assert(x >= 0 && x <= 1 && y >= 0 && y <= 1);
    assert(f >= 0 && f < 16);
    return (f >> (x*2+y)) & 1;
  }
  
  void print() {
    cout << nodes.size() << endl;
    for (int i = N; i < (int)nodes.size(); ++i) {
      cout << get<0>(nodes[i]) << ' ' << get<1>(nodes[i]) << ' ';
      for (int j = 0; j < 4; ++j)
        cout << ((get<2>(nodes[i])>>j)&1);
      cout << endl;
    }
  }
  
  vector<int> compute_all(vector<int> input) {
    assert((int)input.size() == N);
    vector<int> results(nodes.size());
    for (int i = 0; i < N; ++i) results[i] = input[i];
    for (int i = N; i < (int)nodes.size(); ++i) {
      //cerr << "results[" << i << "] = " << results[i] << endl;
      //cerr << "f=" << get<2>(nodes[i]) << " [" << get<0>(nodes[i]) << ", " << get<1>(nodes[i]) << "]" << endl;
      //cerr << results[get<0>(nodes[i])] <<
      //                            results[get<1>(nodes[i])] << endl;
      results[i] = compute_binary(results[get<0>(nodes[i])],
                                  results[get<1>(nodes[i])],
				  get<2>(nodes[i]));
    }
    return results;
  }
  
  int add_gate(int in1, int in2, int f) {
   // cerr << nodes.size()<< endl;
    assert(in1 < (int)nodes.size() && in2 < (int)nodes.size());
    nodes.push_back(make_tuple(in1, in2, f));
    return (int)nodes.size()-1;
  }
  
  // bits of in1 and in2 from small to large
  vector<int> add_sum(vector<int> in1, vector<int> in2) {
    while (in1.size() < in2.size()) in1.push_back(gate0);
    while (in2.size() < in1.size()) in2.push_back(gate0);
    int carry = -1;
    vector<int> result;
    for (int i = 0; i < (int)in1.size(); ++i) {
      if (carry == -1) {
        result.push_back(add_gate(in1[i], in2[i], O_XOR));
	carry = add_gate(in1[i], in2[i], O_AND);
      }
      else {
	int tmp1 = add_gate(in1[i], in2[i], O_AND);
	int tmp2 = add_gate(in1[i], in2[i], O_OR);
	int tmp3 = add_gate(tmp2, carry, O_AND);	
	int new_carry = add_gate(tmp1, tmp3, O_OR);	
	// carry = (in1 & in2) | (carry & (in1 | in2))	
	int tmp4 = add_gate(in1[i], in2[i], O_XOR);
	result.push_back(add_gate(tmp4, carry, O_XOR));
	carry = new_carry;
      }     
    }
    result.push_back(carry);
    return result;
  }
  
  vector<int> add_inc(vector<int> in) {
    return add_sum(in, {gate1});
  }
  
  vector<int> add_sum_bits(vector<int> in) {
    if (in.size() == 0) {
      return {gate0};
    }
    vector<vector<int>> cur;
    for (int i = 0; i < (int)in.size(); ++i) {
      cur.push_back({in[i]});
    }
    while (cur.size() > 1) {
      vector<vector<int>> new_cur;
      for (int i = 0; i < (int)cur.size(); i+=2) {
	if (i + 1 == (int)cur.size()) new_cur.push_back(cur[i]);
	else new_cur.push_back(add_sum(cur[i], cur[i+1]));
      }
      cur = new_cur;
    }
    return cur[0];
  }
  
  int add_op_bits(vector<int> in, int op) {
    assert(in.size() > 0);
    vector<int> cur = in;    
    while (cur.size() > 1) {
      vector<int> new_cur;
      for (int i = 0; i < (int)cur.size(); i+=2) {
	if (i + 1 == (int)cur.size()) new_cur.push_back(cur[i]);
	else new_cur.push_back(add_gate(cur[i], cur[i+1], op));
      }
      cur = new_cur;
    }
    return cur[0];
  }
  
  vector<int> div2(vector<int> in) {
    vector<int> ans;
    for (int i = 1; i < (int)in.size(); ++i)
      ans.push_back(in[i]);
    return ans;
  }
  
  int add_equals(vector<int> in1, vector<int> in2) {  
    while (in1.size() < in2.size()) in1.push_back(gate0);
    while (in2.size() < in1.size()) in2.push_back(gate0);      
    vector<int> r(in1.size());
    for (int i = 0; i < (int)in1.size(); ++i) 
      r[i] = add_gate(in1[i], in2[i], O_EQ);    
    return (r.size() > 0 ? add_op_bits(r, O_AND) : gate1);
  }
  
  int add_less(vector<int> in1, vector<int> in2) {
    while (in1.size() < in2.size()) in1.push_back(gate0);
    while (in2.size() < in1.size()) in2.push_back(gate0);
    reverse(in1.begin(), in1.end());
    reverse(in2.begin(), in2.end());
    int still_equal = gate1;
    int bigger = gate0;
    vector<int> less_at_bit(in1.size());
    for (int i = 0; i < (int)in1.size(); ++i) {
      int bit_bigger = add_gate(in1[i], in2[i], O_GT);
      int bit_less = add_gate(in1[i], in2[i], O_LS);
      bit_less = add_gate(bit_less, bigger, O_xANDnoty);
      less_at_bit[i] = add_gate(still_equal, bit_less, O_AND);
      bit_bigger = add_gate(bit_bigger, still_equal, O_AND); 
      bigger = add_gate(bigger, bit_bigger, O_OR);
      bigger = add_gate(bigger, less_at_bit[i], O_xANDnoty);
      int tmp1 = add_gate(in1[i], in2[i], O_EQ);
      still_equal = add_gate(still_equal, tmp1, O_AND);         
    }
    return (less_at_bit.size() > 0 ? add_op_bits(less_at_bit, O_OR) : gate0);
  }
  
  int add_bigger(vector<int> in1, vector<int> in2) {
    int r = add_less(in1, in2);
    int z = add_equals(in1, in2);
    return add_gate(z, r, O_notxANDnoty);
  }
  
  int add_lessorequal(vector<int> in1, vector<int> in2) {
     int r = add_less(in1, in2);
     int z = add_equals(in1, in2);
     return add_gate(r,z, O_OR);
  }
  
  int add_biggerorequal(vector<int> in1, vector<int> in2) {
    return add_gate(gate0, add_less(in1,in2), O_NOT2);
  }
  
  vector<int> add_argop(vector<int> in1, vector<int> in2, int res_op) {
    // res_op = 0 -> in1 otherwise in2
    while (in1.size() < in2.size()) in1.push_back(gate0);
    while (in2.size() < in1.size()) in2.push_back(gate0);
    vector<int> res(in1.size());
    for (int i = 0; i < (int)in1.size(); ++i) {
      int tmp1 = add_gate(in1[i], res_op, O_xANDnoty);
      int tmp2 = add_gate(in2[i], res_op, O_AND);
      res[i] = add_gate(tmp1, tmp2, O_OR);      
    }
    return res;
  }
  
  vector<int> const_to_gates(int a) {
    vector<int> ans;
    while (a) {
      ans.push_back(a % 2 == 1 ? gate1 : gate0);
      a /= 2;
    }
    if ((int)ans.size() == 0) ans.push_back(gate0);
    return ans;
  }
  
  
  
  static void run_tests() {
    // test_functions
    {
      Circuit x(1);
      for (int a = 0; a < 2; ++a)
      for (int b = 0; b < 2; ++b) {
	
	//const int O_XOR = 6;
	if (x.compute_binary(a,b,O_XOR) != (a ^ b)) {
	  cerr << "XOR failed " << a << ' ' << b << endl;
	}
	//const int O_OR = 14;
	if (x.compute_binary(a,b,O_OR) != (a | b)) {
	  cerr << "OR failed " << a << ' ' << b << endl;
	}
	//const int O_AND = 8;
	if (x.compute_binary(a,b,O_AND) != (a & b)) {
	  cerr << "AND failed " << a << ' ' << b << endl;
	}
	//const int O_1 = 12;
	if (x.compute_binary(a,b,O_1) != (a)) {
	  cerr << "1 failed " << a << ' ' << b << endl;
	}
	//const int O_2 = 10;
	if (x.compute_binary(a,b,O_2) != (b)) {
	  cerr << "2 failed " << a << ' ' << b << endl;
	}
	//const int O_NOT1 = 3;
	if (x.compute_binary(a,b,O_NOT1) != (1-a)) {
	  cerr << "NOT1 failed " << a << ' ' << b << endl;
	}
	//const int O_NOT2 = 5;
	if (x.compute_binary(a,b,O_NOT2) != (1-b)) {
	  cerr << "NOT2 failed " << a << ' ' << b << endl;
	}
	//const int O_id0 = 0;
	if (x.compute_binary(a,b,O_id0) != 0) {
	  cerr << "id0 failed " << a << ' ' << b << endl;
	}
	//const int O_id1 = 15;
	if (x.compute_binary(a,b,O_id1) != 1) {
	  cerr << "id1 failed " << a << ' ' << b << endl;
	}
	//const int O_EQ = 9;
	if (x.compute_binary(a,b,O_EQ) != (a==b)) {
	  cerr << "EQ failed " << a << ' ' << b << endl;
	}
	//const int O_GT = 4;
	if (x.compute_binary(a,b,O_GT) != (a > b)) {
	  cerr << "GT failed " << a << ' ' << b << endl;
	}
	//const int O_LS = 2;
	if (x.compute_binary(a,b,O_LS) != (a < b)) {
	  cerr << "LS failed " << a << ' ' << b << endl;
	}
	//const int O_xANDnoty = 4;
	if (x.compute_binary(a,b,O_xANDnoty) != (a & (1-b))) {
	  cerr << "xANDnoty failed " << a << ' ' << b << endl;
	}
	//const int O_notxANDnoty = 1;
	if (x.compute_binary(a,b,O_notxANDnoty) != ((1-a) & (1-b))) {
	  cerr << "notxANDnoty failed " << a << ' ' << b << endl;
	}
	//const int O_notxORy = 11;
	if (x.compute_binary(a,b,O_notxORy) != ((1-a) | b)) {
	  cerr << "notxORy failed " << a << ' ' << b << endl;
	}
      }
    }
    
    // test sum_bits
    {
      Circuit x(7);
      vector<int> res = x.add_sum_bits({0,1,2,3,4,5,6});
      for (int _ = 0; _ < 10; ++_) {
	vector<int> in(7);
	int corr = 0;
	for (int i = 0; i < 7; ++i) {
	  in[i] = rand() % 2;
	  corr += in[i];
	}
	vector<int> r = x.compute_all(in);
	int result = 0;
	for (int i = 0; i < (int)res.size(); ++i) result += r[res[i]] << i;
	if (corr != result) {
	  cerr << "TEST FAILED: ";
	  for (int i = 0; i < 7; ++i) cerr << in[i];
	  cerr << endl;
	  break;	  
	}
      }
      cerr << "SUM BITS PASSED" << endl;
    }
    {
      Circuit x(10);
      int biggerid = x.add_bigger({0,1,2,3,4},{5,6,7,8,9});
      int LEid = x.add_lessorequal({0,1,2,3,4},{5,6,7,8,9});
      int GEid = x.add_biggerorequal({0,1,2,3,4},{5,6,7,8,9});
      for (int _ = 0; _ < 100; ++_) {
	 vector<int> in(10);
	 int a = rand() % 32;
	 int b = rand() % 32;
	 for (int i = 0; i < 5; ++i) in[i] = (a>>i) & 1;
	 for (int i = 0; i < 5; ++i) in[5+i] = (b>>i)&1;
	 if ((a > b) != x.compute_all(in)[biggerid]) {
	   cerr << "TEST bigger FAILED: ";
	   cerr << a << ' ' << b << endl;
	   for (int i = 0; i < 10; ++i) cerr << in[i];
	   cerr << endl;
	   break;
	 }   
	 if ((a <= b) != x.compute_all(in)[LEid]) {
	   cerr << "TEST <= FAILED: ";
	   cerr << a << ' ' << b << endl;
	   for (int i = 0; i < 10; ++i) cerr << in[i];
	   cerr << endl;
	   break;
	 }  
	 if ((a >= b) != x.compute_all(in)[GEid]) {
	   cerr << "TEST >= FAILED: ";
	   cerr << a << ' ' << b << endl;
	   for (int i = 0; i < 10; ++i) cerr << in[i];
	   cerr << endl;
	   break;
	 }    	
      }
      cerr << "COMPARISONS PASSED" << endl;
    }
    {
      Circuit x(20);
      vector<int> half1;
      vector<int> half2;
      for (int i = 0; i < 20; ++i) 
        if (i < 10) half1.push_back(i);
	else half2.push_back(i);
      int bigger_result = x.add_bigger(half1, half2);
      vector<int> bigger_number = 
          x.add_argop(half2, half1,
		      bigger_result);
      vector<int> first_number = x.add_argop(half1, half2, x.gate0);
      vector<int> second_number = x.add_argop(half1, half2, x.gate1);
      for (int _ = 0; _ < 100; ++_) {
	int a = rand() % 1024;
	int b = rand() % 1024;
	vector<int> bits_a(10);
	vector<int> bits_b(10);
	for (int i = 0; i < 10; ++i) {
	  bits_a[i] = (a >> i) & 1;
	  bits_b[i] = (b >> i) & 1;
	}
	vector<int> r = bits_a;
	r.insert(r.end(), bits_b.begin(), bits_b.end());
	vector<int> R = x.compute_all(r);
	vector<int> bigger_out(10);
	for (int i = 0; i < 10; ++i) bigger_out[i] = R[bigger_number[i]];
	vector<int> first_out(10);
	for (int i = 0; i < 10; ++i) first_out[i] = R[first_number[i]];
	vector<int> second_out(10);
	for (int i = 0; i < 10; ++i) second_out[i] = R[second_number[i]];
	if (bits_a != first_out) {
	  cerr << "TEST first FAILED: ";
	   cerr << a << ' ' << b << endl;
	   break;
	}
	if (bits_b != second_out) {
	  cerr << "TEST second FAILED: ";
	   cerr << a << ' ' << b << endl;
	   break;
	}
	if ((a>b) != R[bigger_result]) {
	   cerr << "TEST bigger FAILED: " << a << b << endl;
	   break;
	}
	if ((a>b ? bits_a : bits_b) != bigger_out) {
	  cerr << "TEST argop(bigger) FAILED: ";
	   cerr << a << ' ' << b << endl;
	   for (int i = 0; i < 10; ++i) {
	     cerr << bits_a[i];
	   }
	   cerr << endl;
	   for (int i = 0; i < 10; ++i) {
	     cerr << bits_b[i];
	   }
	   cerr << endl;
	   for (int i = 0; i < 10; ++i) {
	     cerr << bigger_out[i];
	   }
	   cerr << endl;
	   break;
	}
      }
      cerr << "ARGOP PASSED" << endl; 
    }
  }
};

namespace G {

const int maxn = (int)1e5, maxt = 10;
int n,m,k, T;

vector<int> my_cliques[maxt];
vector<int> my_iss[maxt];
bool answer[maxt];
vector<int> con[maxn];
Circuit createCircuit(bool needBig) {
  Circuit X(n + 2*k);
  // establish the state.
  vector<int> test_input(n + 2*k);
  { // Testing
    for (int i = 0; i < n; ++i)
      test_input[i] = (needBig ? my_iss[0][i] : my_cliques[0][i]);
    
  }
  vector<int> comm(2*k);
  for (int i = 0; i < 2*k; ++i) comm[i] = n + i;
  vector<int> all_zero(2*k);
  vector<int> is_stage(2*k);
  all_zero[2*k-1] = X.add_gate(X.gate0, comm[2*k-1], O_NOT2);
  for (int i = 2*(k-1); i >= 0; --i)
    all_zero[i] = X.add_gate(all_zero[i+1], comm[i], O_xANDnoty);
  is_stage[2*k-1] = X.gate0;
  for (int i = 1; i < 2*k-1; ++i) 
    is_stage[i] = X.add_gate(all_zero[i+1], comm[i], O_AND);
  is_stage[0] = all_zero[0];  
  vector<int> is_actual(2*k);
  is_actual[2*k-1] = X.gate0;
  for (int i = 2*k-2; i >= 0; --i)
    is_actual[i] = X.add_gate(is_actual[i+1], is_stage[i+1], O_OR);
  
  int logn = 0;
  while ((1<<logn) < n) logn++;
  cerr << "READY FOR KNOWN " << X.nodes.size() << endl;
  vector<int> knownClique(n, X.gate0);
  vector<int> knownIS(n, X.gate0);
  int max_delta = 0;
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j*2*(logn+1) < 2*k; ++j) {
      for (int d = 0; d < 2; ++d) {
        vector<int> number(logn);
	for (int t = 0; t < logn; ++t) 
	  number[t] = comm[d+j*2*(logn+1)+2*t];
	if (d + j*2*(logn+1) + 2*(logn-1) >= 2*k) continue;
	int before_cnt = X.nodes.size();
	int tmp0 = is_actual[d+j*2*(logn+1) + 2*(logn - 1)];
	int res = X.add_equals(number, X.const_to_gates(i));
	int after_cnt = X.nodes.size();
	res = X.add_gate(tmp0, res, O_AND);
	if (d == 0) knownClique[i] = X.add_gate(res, knownClique[i], O_OR);
	else knownIS[i] = X.add_gate(knownIS[i], res, O_OR);	
	max_delta = max(max_delta, after_cnt - before_cnt);
      }
    }
  }
  
 { // TESTING
    vector<int> test_output = X.compute_all(test_input);
    cerr << "stage:\n";
    for (int i = 0; i < 2*k; ++i) cerr << test_output[is_stage[i]];
    cerr << endl;
    cerr << "knownIS:\n";
    for (int i = 0; i < n; ++i) cerr << test_output[knownIS[i]];
    cerr << endl;
    cerr << "knownClique:\n";
    for (int i = 0; i < n; ++i) cerr << test_output[knownClique[i]];
    cerr << endl;
    
    /*for (int i = 3; i < 2*k; ++i)
      assert(test_output[all_zero[i]] == 1);
    for (int i = 3; i < 2*k; ++i)
      assert(test_output[is_actual[i]] == 0);
    
    assert(test_output[is_stage[2]] == 1);
    for (int i = 0; i < n; ++i) assert(test_output[knownClique[i]] == 0);
    for (int i = 0; i < n; ++i) assert(test_output[knownIS[i]] == 0);
    */
  }
  
  cerr << "CREATED KNOWN" << ' ' << X.nodes.size() << ' ' << max_delta << endl;
  vector<int> cnt_clique = X.add_sum_bits(knownClique);
  vector<int> cnt_IS = X.add_sum_bits(knownIS);
  
  vector<int> is_good(n); // correct w.r.t known
  // i.e. have to connect with all knownClique
  // and     not connect  with all knownIS
  for (int i = 0; i < n; ++i) {
    vector<int> connections;
    vector<int> connect_IS;
    for (int j : con[i]) {
      connections.push_back(knownClique[j]);
      connect_IS.push_back(X.add_gate(X.gate0, knownIS[j], O_NOT2));
    }
    connections.push_back(knownClique[i]);
    vector<int> sum_con = X.add_sum_bits(connections);
    
    int good_clique = X.add_equals(sum_con, cnt_clique);
    int good_IS = (connect_IS.size() > 0 ? X.add_op_bits(connect_IS, O_AND) : X.gate1);
    is_good[i] = X.add_gate(good_clique, good_IS, O_AND);
  }
  
  cerr << "CREATED IS GOOD" << ' ' << X.nodes.size() << endl;
  vector<int> good_count = X.add_sum_bits(is_good);
  vector<vector<int>> good_degree(n);
  for (int i = 0; i < n; ++i) {
    vector<int> gcon;
    for (int j : con[i]) {
      gcon.push_back(is_good[j]);
    }
    good_degree[i] = X.add_sum_bits(gcon);
  }
  
  vector<int> possible = is_good;
  for (int i = 0; i < n; ++i)
     possible[i] = X.add_gate(is_good[i], i, O_AND);
  { // TESTING
    vector<int> test_output = X.compute_all(test_input);
    cerr << "isGood:\n";
    for (int i = 0; i < n; ++i) cerr << test_output[is_good[i]];
    cerr << endl;
   
  }
  
  // we find the vertex from CLIQUE/IS with min/max degree
  // and chech if the resulting degree is (<=n/2) / (>=n/2) respectively.
  // we print [vertex number] [ok/not ok] 
  vector<int> best_ver(logn, X.gate0); // vertex from CLIQUE/IS with min/max
                                       // good degree
  vector<int> cur_degree;
  if (needBig) {
    cur_degree = vector<int>(logn, X.gate0);
  } else {
    cur_degree = vector<int>(logn, X.gate1);
  }
  for (int i = 0; i < n; ++i) {
    best_ver = X.add_argop(best_ver, X.const_to_gates(i), i);
    cur_degree = X.add_argop(cur_degree, good_degree[i], i);
  }
  for (int i = 0; i < n; ++i) {
    int is_in = i; // input gate
    vector<int> number = X.const_to_gates(i);
    int better_degree = -1;
    if (needBig) better_degree = X.add_biggerorequal(good_degree[i], cur_degree);
    else better_degree = X.add_lessorequal(good_degree[i], cur_degree);
    int result =  X.add_gate(is_in, better_degree, O_AND);
    int already_known = (needBig ? knownIS[i] : knownClique[i]);
    result = X.add_gate(result, already_known, O_xANDnoty);
    best_ver = X.add_argop(best_ver, number, result);
    cur_degree = X.add_argop(cur_degree, good_degree[i], result);
  }
  vector<int> threshold = X.div2(good_count);
  int good_result = -1;
  if (needBig) good_result = X.add_biggerorequal(cur_degree, threshold);
  else good_result = X.add_lessorequal(cur_degree, threshold);
  int any_good = (good_count.size() > 0 ? X.add_op_bits(possible, O_OR) : X.gate0);
  // if there is no good vertices then the answer should be equal 0.  
  good_result = X.add_gate(good_result, any_good, O_AND);
  
  { //Testing
    vector<int> test_output = X.compute_all(test_input);
    cerr << "vertex" << endl;
    for (int i = 0; i < (int)best_ver.size(); ++i)
      cerr << test_output[best_ver[i]];    
    cerr << endl;
    cerr << "degree" << endl;
    for (int i = 0; i < (int)cur_degree.size(); ++i)
      cerr << test_output[cur_degree[i]];    
    cerr << endl;
    cerr << "good_result=";
    cerr << test_output[good_result] << endl;
  }
  
  
  // not we have computed best_ver and good_result which are the answer
  // for one communication round. the remaining technical part is to
  // determine which bit of these to send in the current 
  vector<int> stage_bits(2*k-2);
  vector<int> computed_answers;
  for (int i = 0; i < 2*k-2; ++i) {
    int real_stage = i / 2;
    int step = real_stage % (logn + 1);
    stage_bits[i] = X.add_gate(is_stage[i],(step < logn ? best_ver[step]
                              : good_result), O_AND);			      
  }
  for (int i = 0; i*2*(logn+1)+2*logn+1 < 2*k; ++i) {
    int u1 = comm[i*2*(logn+1)+2*logn+1];
    int u2 = comm[i*2*(logn+1)+2*logn];
    computed_answers.push_back(
       X.add_gate(is_actual[i*2*(logn+1)+2*logn+1],
                  X.add_gate(u1, u2, O_OR),
                  O_notxORy));
  }
  // the case when the stage is 2*k-2
  int final_result = 
        
	X.add_gate(X.add_gate(any_good,is_stage[2*k-2],O_AND),
                   (computed_answers.size() > 0 ? X.add_op_bits(computed_answers, O_AND)
		    : X.gate1),
		   O_AND);  
  int result = X.add_gate(final_result, 
                          X.add_gate(is_stage[2*k-2],X.add_op_bits(stage_bits, O_OR),O_notxANDy),
			  O_OR);
			  
  { //Testing
    vector<int> test_output = X.compute_all(test_input);
    cerr << "computed_answers:\n";
    for (int j : computed_answers) cerr << test_output[j];
    cerr << endl;
    cerr << "stage=";
    for (int j = 0; j < (int)is_stage.size(); ++j) 
      if (test_output[is_stage[j]]) cerr << j;
    cerr <<endl;
    cerr << "final_result=" << test_output[final_result] <<endl;
    for (int j : is_stage) cerr << test_output[j];
    cerr << endl;
    for (int j : stage_bits) cerr << test_output[j];
    cerr << endl;
    cerr << "result=" << test_output[result] << endl;
  }
  return X;
  
}

} // namespace G


int main() {
  Circuit::run_tests();
  
  cin >> G::n >> G::m >> G::k;
  for (int i = 0; i < G::n; ++i) G::con[i].clear();
  for (int i = 0; i <G::m; ++i) {
    int a,b;
    cin >> a >> b;
    a--; b--;
    G::con[a].push_back(b);
    G::con[b].push_back(a);
  }
  
 // cin >> G::T;
  G::T = 1;
  for (int i = 0; i < G::T; ++i) {
    G::my_cliques[i].resize(G::n);
    G::my_iss[i].resize(G::n);
   // for (int j = 0; j < G::n; ++j) cin >>G:: my_cliques[i][j];
   // for (int j = 0; j < G::n; ++j) cin >> G::my_iss[i][j];
    G::answer[i] = false;
    for (int j = 0; j < G::n; ++j)
      if (G::my_cliques[i][j] && G::my_iss[i][j]) 
        G::answer[i] = true;
    
  }
  G::createCircuit(false).print();
  G::createCircuit(true).print();
  
}

