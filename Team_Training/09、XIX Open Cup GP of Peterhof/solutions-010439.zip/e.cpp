#include <vector>
#include <iostream>
#include <cassert>

using namespace std;

#define sz(c) int((c).size())

int x, y;

bool read() {
    if (!(cin >> x >> y)) {
        return 0;
    }
    return 1;
}

double solve() {
    vector<double> p(1 + x + y);
    for (int i = x + 1; i < sz(p); ++i) {
        p[i] = 1;
    }

    for (int i = sz(p) - 1; i > 1; --i) {
        const int j = i / 2;
        assert(j < i);
        p[j] = (p[i] + p[j]) * 0.5;
    }

    return p[1];
}

int main() {
    cout.precision(20);
    cout << fixed;

    while (read()) {
        auto ans = solve();
        cout << ans << "\n";
    }
}

