#include "bits/stdc++.h"
#include <memory>
using namespace std;

typedef long long int64;

int64 op(const int64 &a, const int64 &b) {
  if (a == -1) return b;
  if (b == -1) return a;
  cout << "? " <<  a << ' ' << b << "\n";
  cout.flush();
  //return a ^ b;
  int64 c;
  cin >> c;
  if (c == -1) {
    cerr << "TOO MANY OPEERATIONS"<< endl;
  }
  return c;
}

typedef unique_ptr<const struct Tree> pTree;
struct Tree {
  vector<int64> suprefix;
  vector<int64> at;
  int l, r, m;
  pTree left, right;
  Tree (vector<int64> &a, int _l, int _r): left(nullptr),
                                           right(nullptr)  { // [l, r)   
    l = _l; r = _r;
    for (int i = l; i < r; ++i) at.push_back(a[i]);
    m = (l + r) / 2;
    suprefix.resize(r-l);
    
    if (m-1 >= l) suprefix[(m-1)-l] = a[m-1];
    for (int i = m-2; i >= l; --i) {
      suprefix[i-l] = op(a[i], suprefix[i+1-l]);
    }
    if (m >= l) suprefix[m-l] = a[m];
    for (int i = m+1; i < r; ++i)
      suprefix[i-l] = op(suprefix[i-1-l], a[i]);
    if (r > l + 1) {
      if (m > l) {
	auto my_left = unique_ptr<const Tree>(new Tree(a, l, m));	
	left = std::move(my_left);
      }
      if (m < r) {
	auto my_right = unique_ptr<const Tree>(new Tree(a, m, r));
	right = std::move(my_right);
      }
    }
  }
  int64 query(int ql, int qr) const {
    assert(ql < qr);
    assert(l <= ql && qr <= r);
    //cerr << ql << ' ' << qr << endl;
    if (ql == qr - 1) return at[ql-l];
    if (qr <= m) return left->query(ql,qr);
    if (ql >= m) return right->query(ql,qr);
    return op(suprefix[ql-l], suprefix[qr-1-l]);
  }
  
};

int main() {
  int n,q,k;
  cin >> n >> q >> k;
  vector<int64> a(n);
  for (int i = 0; i < n; ++i) {
    cin >> a[i];
  }
  
  // shuffle the input
  vector<int> p(n);
  for (int i = 0; i < n; ++i) p[i] = i;
  random_shuffle(p.begin(), p.end());
  vector<int64> aprime(n);
  for (int i = 0; i < n; ++i) aprime[p[i]] = a[i];
  a = aprime;
  
  //for (int i = 0; i < n; ++i) cerr << a[i] << ' ';
  //cerr << endl;
  int logn = 0;
  while ((1<<logn) < n) ++logn;
  vector<int64> prefix(n);
  vector<int64> suffix(n);
  for (int i = 0; i < n; ++i)
    if (i % logn == 0) prefix[i] = a[i];
    else prefix[i] = op(prefix[i-1], a[i]);
  suffix[n-1] = a[n-1];
  for (int i = n-2; i >= 0; --i)
    if (i % logn == logn - 1) suffix[i] = a[i];
    else suffix[i] = op(a[i], suffix[i+1]);
  vector<int64> compressed((n-1)/logn + 1);
  for (int i = 0; i*logn < n; ++i) {
    assert(i < (int)compressed.size());
    compressed[i] = suffix[i*logn];
  }
  
  unique_ptr<const Tree> mytree(new Tree(compressed, 0, (int)compressed.size()));
  const Tree* treeptr = mytree.get();
  int bad = 0;
  auto lrquery = [suffix, prefix, a, treeptr, logn, &bad] (int l, int r) {
    int lbuck = l / logn;
    int rbuck = r / logn;
   // cerr << l << "->" << lbuck << " " << r << "->" << rbuck <<endl;
    if (lbuck == rbuck) {
      int64 res = a[l];
      for (int j = l+1; j <= r; ++j) res = op(res, a[j]);
      bad++;
      return res;
    }
    int64 res0 = op(suffix[l], prefix[r]);
    if (lbuck+1 < rbuck) res0 = op(res0, treeptr->query(lbuck+1,rbuck));
    return res0;
  };
 // cerr << "something" << endl;
  for (int i = 0; i < q; ++i) {
    cout << "next\n";
    cout.flush();
    vector<int> ex(k);
    for (int j = 0; j < k; ++j) {
      cin >> ex[j];
  //    cerr << "ex=" << ex[j] << endl;
      ex[j] = p[ex[j]-1];
    }
    sort(ex.begin(), ex.end());
    int64 pref = (ex[0] > 0 ? lrquery(0, ex[0]-1) : -1);
    int64 suff = (ex.back() < n-1 ? lrquery(ex.back()+1, n-1) : -1);
    int64 res = op(pref,suff);
    for (int i = 1; i < (int)ex.size(); ++i)
      if (ex[i] > ex[i-1] + 1) {
    	res = op(res, lrquery(ex[i-1]+1, ex[i]-1));
      }
    cout << "! " << res << "\n";
    cout.flush();
  }
}

